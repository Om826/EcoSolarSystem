# eSolar — Local LAMP Setup Guide

## Project Structure

```
esolar/
├── index.php              ← Homepage
├── products.php           ← Product listing
├── product.php            ← Product detail
├── register.php           ← Customer registration
├── login.php              ← Customer login
├── logout.php
├── cart.php               ← Shopping cart
├── checkout.php           ← Delivery address
├── payment.php            ← Dummy payment + order creation
├── orders.php             ← Customer order history
├── order-detail.php       ← Single order view
├── esolar.sql             ← Full database schema + seed data
├── includes/
│   ├── config.php         ← DB config + PDO connection
│   ├── functions.php      ← Auth, cart, helpers
│   ├── header.php
│   └── footer.php
├── assets/
│   ├── css/style.css
│   └── js/main.js
└── admin/
    ├── login.php          ← Admin login (admin / admin123)
    ├── logout.php
    ├── dashboard.php      ← Stats + recent orders
    ├── products.php       ← Product list + toggle/delete
    ├── product-add.php    ← Add new product
    ├── product-edit.php   ← Edit existing product
    ├── orders.php         ← All orders + status update
    ├── order-detail.php   ← Single order admin view
    ├── customers.php      ← Customer list
    ├── reports.php        ← Reports + CSV export
    ├── admin-header.php
    ├── admin-footer.php
    └── admin.css
```

---

## Step 1 — Prerequisites

Make sure XAMPP (or WAMP) is running with:
- Apache ✅
- MySQL ✅
- PHP 8.0+ ✅

---

## Step 2 — Copy Project Files

Copy the `esolar/` folder into your web root:

**XAMPP:**
```
C:\xampp\htdocs\esolar\
```

**WAMP:**
```
C:\wamp64\www\esolar\
```

---

## Step 3 — Create the Database

1. Open your browser → go to `http://localhost/phpmyadmin`
2. Click **"New"** (left sidebar) → type database name: `esolar` → click **Create**
3. Select the `esolar` database → click **Import** tab
4. Click **Choose File** → select `esolar.sql` from the project folder
5. Click **Go** → wait for success message

OR use terminal:
```bash
mysql -u root -p < C:/xampp/htdocs/esolar/esolar.sql
```

---

## Step 4 — Configure Database Connection

Open `includes/config.php` and verify:

```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');   // your MySQL username
define('DB_PASS', '');       // your MySQL password (empty for XAMPP default)
define('DB_NAME', 'esolar');
define('SITE_URL', 'http://localhost/esolar');
```

---

## Step 5 — Launch the Site

Open your browser:

| URL | Purpose |
|-----|---------|
| `http://localhost/esolar/` | Customer storefront |
| `http://localhost/esolar/register.php` | Create customer account |
| `http://localhost/esolar/login.php` | Customer login |
| `http://localhost/esolar/admin/login.php` | Admin panel |

---

## Default Admin Credentials

```
Username: admin
Password: admin123
```

> ⚠️ Change this in production! Update the password hash in the `admins` table via phpMyAdmin.

---

## Payment (Dummy)

The payment page is a **fully functional dummy**:
- Accepts card, UPI, net banking, or COD
- No real payment gateway is called
- All order + payment details are saved to the database
- Order status is set to `confirmed`, payment status to `paid`

To test:
1. Add products to cart
2. Register/login as a customer
3. Checkout → fill address → Pay
4. Use any card number (e.g. `4111 1111 1111 1111`)

---

## Admin Features

| Feature | Location |
|---------|---------|
| Dashboard with stats | `admin/dashboard.php` |
| Add/Edit/Delete products | `admin/products.php`, `product-add.php`, `product-edit.php` |
| Manage order status | `admin/orders.php` → inline dropdown |
| View order detail | `admin/order-detail.php` |
| Customer list | `admin/customers.php` |
| Sales reports | `admin/reports.php` |
| CSV export (orders/products/customers) | `admin/reports.php` → Export buttons |

---

## Troubleshooting

**Blank page / 500 error:**
- Enable PHP error display: add `ini_set('display_errors',1); error_reporting(E_ALL);` to top of `includes/config.php`

**"Database Connection Failed":**
- Check `DB_USER` and `DB_PASS` in `config.php`
- Make sure MySQL is running in XAMPP/WAMP

**Page not found:**
- Verify `SITE_URL` in `config.php` exactly matches your URL
- Make sure the folder name is exactly `esolar`

**Images not loading:**
- Products use emoji icons (no image uploads needed)

---

## To Change Admin Password

```sql
UPDATE admins SET password_hash = '$2y$10$YOUR_NEW_HASH' WHERE username = 'admin';
```

Generate a new hash in PHP:
```php
echo password_hash('your_new_password', PASSWORD_DEFAULT);
```

---

Built with ❤️ using PHP 8 + MySQL + Vanilla CSS | eSolar © <?= date('Y') ?>

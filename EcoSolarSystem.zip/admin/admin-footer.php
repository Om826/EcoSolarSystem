  </div><!-- /.admin-content -->
</main><!-- /.admin-main -->
</div><!-- /.admin-wrap -->
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>

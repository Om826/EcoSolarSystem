<?php
// Admin header — included at top of every admin page
// Requires $pageTitle to be set before inclusion

require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

$adminUser = 'Admin'; // Could extend to fetch admin name from DB
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) . ' — eSolar Admin' : 'eSolar Admin Panel' ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= SITE_URL ?>/admin/admin.css">
</head>
<body>
<div class="admin-wrap">

<!-- Sidebar -->
<aside class="admin-sidebar">
  <div class="sidebar-logo">
    <span class="logo-icon">☀</span>
    <span class="logo-text">e<strong>Solar</strong></span>
    <span class="admin-badge">Admin</span>
  </div>

  <nav class="admin-nav">
    <div class="nav-section-label">Main</div>
    <a href="<?= SITE_URL ?>/admin/dashboard.php" class="<?= $currentPage==='dashboard.php'?'active':'' ?>">
      <span class="nav-icon">📊</span> Dashboard
    </a>

    <div class="nav-section-label">Catalog</div>
    <a href="<?= SITE_URL ?>/admin/products.php" class="<?= $currentPage==='products.php'?'active':'' ?>">
      <span class="nav-icon">🌞</span> Products
    </a>
    <a href="<?= SITE_URL ?>/admin/product-add.php" class="<?= $currentPage==='product-add.php'?'active':'' ?>">
      <span class="nav-icon">➕</span> Add Product
    </a>

    <div class="nav-section-label">Sales</div>
    <a href="<?= SITE_URL ?>/admin/orders.php" class="<?= $currentPage==='orders.php'?'active':'' ?>">
      <span class="nav-icon">📦</span> Orders
    </a>
    <a href="<?= SITE_URL ?>/admin/customers.php" class="<?= $currentPage==='customers.php'?'active':'' ?>">
      <span class="nav-icon">👥</span> Customers
    </a>

    <div class="nav-section-label">Reports</div>
    <a href="<?= SITE_URL ?>/admin/reports.php" class="<?= $currentPage==='reports.php'?'active':'' ?>">
      <span class="nav-icon">📈</span> Reports
    </a>

    <div class="nav-section-label">System</div>
    <a href="<?= SITE_URL ?>" target="_blank">
      <span class="nav-icon">🌐</span> View Store
    </a>
  </nav>

  <div class="sidebar-footer">
    <a href="<?= SITE_URL ?>/admin/logout.php">🚪 Logout</a>
  </div>
</aside>

<!-- Main -->
<main class="admin-main">
  <div class="admin-topbar">
    <h1><?= isset($pageTitle) ? htmlspecialchars($pageTitle) : 'Dashboard' ?></h1>
    <div class="topbar-right">
      <div class="admin-user">Logged in as <strong><?= htmlspecialchars($adminUser) ?></strong></div>
      <a href="<?= SITE_URL ?>/admin/logout.php" class="btn btn-sm btn-dark">Logout</a>
    </div>
  </div>
  <div class="admin-content">

<?php
// Show flash messages
$sf = getFlash('success');
$ef = getFlash('error');
if ($sf): ?><div class="flash flash-success"><?= htmlspecialchars($sf) ?></div><?php endif;
if ($ef): ?><div class="flash flash-error"><?= htmlspecialchars($ef) ?></div><?php endif;
?>

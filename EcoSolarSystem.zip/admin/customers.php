<?php
$pageTitle = 'Customers';
require_once __DIR__ . '/admin-header.php';
$pdo    = getDB();
$search = trim($_GET['q'] ?? '');
$params = [];
$where  = '';

if ($search) {
    $where  = 'WHERE c.name LIKE ? OR c.email LIKE ? OR c.phone LIKE ?';
    $params = ["%$search%", "%$search%", "%$search%"];
}

$customers = $pdo->prepare("
    SELECT c.*, COUNT(o.id) AS order_count, COALESCE(SUM(o.total_amount),0) AS total_spent
    FROM customers c
    LEFT JOIN orders o ON o.customer_id = c.id AND o.payment_status = 'paid'
    $where
    GROUP BY c.id
    ORDER BY c.created_at DESC
");
$customers->execute($params);
$customers = $customers->fetchAll();
?>

<form method="GET" class="filter-bar">
  <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search by name, email or phone…" style="flex:1;min-width:220px">
  <button type="submit" class="btn btn-primary btn-sm">Search</button>
  <a href="customers.php" class="btn btn-outline btn-sm">Reset</a>
</form>

<div style="font-size:.82rem;color:var(--gray-500);margin-bottom:.75rem"><?= count($customers) ?> customer(s)</div>

<div class="table-wrap">
  <table>
    <thead>
      <tr><th>#</th><th>Name</th><th>Email</th><th>Phone</th><th>City</th><th>Orders</th><th>Total Spent</th><th>Joined</th></tr>
    </thead>
    <tbody>
      <?php if (empty($customers)): ?>
      <tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--gray-500)">No customers found.</td></tr>
      <?php endif; ?>
      <?php foreach ($customers as $c): ?>
      <tr>
        <td style="color:var(--gray-500)"><?= $c['id'] ?></td>
        <td><strong><?= htmlspecialchars($c['name']) ?></strong></td>
        <td><?= htmlspecialchars($c['email']) ?></td>
        <td><?= htmlspecialchars($c['phone'] ?? '—') ?></td>
        <td><?= htmlspecialchars($c['city'] ?? '—') ?><?= $c['state'] ? ', '.$c['state'] : '' ?></td>
        <td><span style="font-weight:700;color:var(--solar-orange)"><?= $c['order_count'] ?></span></td>
        <td><strong>₹<?= number_format($c['total_spent'], 2) ?></strong></td>
        <td><?= date('d M y', strtotime($c['created_at'])) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>

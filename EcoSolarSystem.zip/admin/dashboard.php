<?php
$pageTitle = 'Dashboard';
require_once __DIR__ . '/admin-header.php';
$pdo = getDB();

// Stats
$totalRevenue   = $pdo->query("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE payment_status='paid'")->fetchColumn();
$totalOrders    = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$totalCustomers = $pdo->query("SELECT COUNT(*) FROM customers")->fetchColumn();
$totalProducts  = $pdo->query("SELECT COUNT(*) FROM products WHERE is_active=1")->fetchColumn();
$pendingOrders  = $pdo->query("SELECT COUNT(*) FROM orders WHERE status='pending'")->fetchColumn();
$lowStock       = $pdo->query("SELECT COUNT(*) FROM products WHERE stock < 5 AND is_active=1")->fetchColumn();

// Monthly revenue (last 6 months)
$monthlyRev = $pdo->query("
    SELECT DATE_FORMAT(created_at,'%b %Y') AS month, SUM(total_amount) AS revenue
    FROM orders WHERE payment_status='paid' AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
    GROUP BY DATE_FORMAT(created_at,'%Y-%m') ORDER BY MIN(created_at)
")->fetchAll();

// Recent orders
$recentOrders = $pdo->query("
    SELECT o.*, c.name AS customer_name
    FROM orders o JOIN customers c ON c.id = o.customer_id
    ORDER BY o.created_at DESC LIMIT 8
")->fetchAll();

// Top products
$topProducts = $pdo->query("
    SELECT p.name, p.brand, SUM(oi.quantity) AS qty_sold, SUM(oi.subtotal) AS revenue
    FROM order_items oi JOIN products p ON p.id = oi.product_id
    GROUP BY oi.product_id ORDER BY revenue DESC LIMIT 5
")->fetchAll();
?>

<!-- Stat Cards -->
<div class="stats-grid">
  <div class="stat-card orange">
    <div class="stat-icon">💰</div>
    <div class="stat-info">
      <div class="stat-value"><?= '₹' . number_format($totalRevenue/1000, 1) ?>K</div>
      <div class="stat-label">Total Revenue</div>
    </div>
  </div>
  <div class="stat-card blue">
    <div class="stat-icon">📦</div>
    <div class="stat-info">
      <div class="stat-value"><?= $totalOrders ?></div>
      <div class="stat-label">Total Orders <span style="color:var(--warning)">(<?= $pendingOrders ?> pending)</span></div>
    </div>
  </div>
  <div class="stat-card green">
    <div class="stat-icon">👥</div>
    <div class="stat-info">
      <div class="stat-value"><?= $totalCustomers ?></div>
      <div class="stat-label">Registered Customers</div>
    </div>
  </div>
  <div class="stat-card yellow">
    <div class="stat-icon">🌞</div>
    <div class="stat-info">
      <div class="stat-value"><?= $totalProducts ?></div>
      <div class="stat-label">Active Products <span style="color:var(--danger)">(<?= $lowStock ?> low stock)</span></div>
    </div>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:1.25rem">
  <!-- Monthly Revenue Chart -->
  <div class="card">
    <div class="card-header">
      <h3>Revenue — Last 6 Months</h3>
    </div>
    <?php if ($monthlyRev): ?>
    <div style="display:flex;align-items:flex-end;gap:.5rem;height:120px;padding-top:.5rem">
      <?php
      $maxR = max(array_column($monthlyRev, 'revenue')) ?: 1;
      foreach ($monthlyRev as $m):
        $pct = round(($m['revenue'] / $maxR) * 100);
      ?>
      <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:.3rem;height:100%">
        <div style="font-size:.68rem;color:var(--gray-500)">₹<?= number_format($m['revenue']/1000,1) ?>K</div>
        <div style="flex:1;width:100%;display:flex;align-items:flex-end">
          <div style="width:100%;height:<?= $pct ?>%;background:var(--solar-orange);border-radius:4px 4px 0 0;min-height:4px"></div>
        </div>
        <div style="font-size:.68rem;color:var(--gray-500);white-space:nowrap"><?= htmlspecialchars($m['month']) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="empty-state"><div class="empty-icon">📊</div><p>No revenue data yet.</p></div>
    <?php endif; ?>
  </div>

  <!-- Top Products -->
  <div class="card">
    <div class="card-header"><h3>Top Products by Revenue</h3></div>
    <?php if ($topProducts): ?>
    <table style="width:100%">
      <thead><tr><th style="background:transparent;color:var(--gray-500);font-size:.72rem;padding:.3rem 0;border-bottom:1px solid var(--gray-200)">Product</th><th style="background:transparent;color:var(--gray-500);font-size:.72rem;padding:.3rem 0;border-bottom:1px solid var(--gray-200);text-align:right">Revenue</th></tr></thead>
      <tbody>
      <?php foreach ($topProducts as $tp): ?>
      <tr>
        <td style="padding:.5rem 0;font-size:.82rem;border-bottom:1px solid var(--gray-100)"><?= htmlspecialchars(substr($tp['name'],0,32)) ?>…</td>
        <td style="padding:.5rem 0;font-size:.82rem;border-bottom:1px solid var(--gray-100);text-align:right;font-weight:700;color:var(--solar-orange)">₹<?= number_format($tp['revenue'],0) ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><div class="empty-icon">🛍</div><p>No sales yet.</p></div>
    <?php endif; ?>
  </div>
</div>

<!-- Recent Orders -->
<div class="card">
  <div class="card-header">
    <h3>Recent Orders</h3>
    <a href="orders.php" class="btn btn-sm btn-outline">View All →</a>
  </div>
  <?php if ($recentOrders): ?>
  <div class="table-wrap" style="box-shadow:none">
    <table>
      <thead>
        <tr>
          <th>Order #</th><th>Customer</th><th>Date</th><th>Amount</th><th>Payment</th><th>Status</th><th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($recentOrders as $o): ?>
        <tr>
          <td><strong style="color:var(--solar-orange)"><?= htmlspecialchars($o['order_number']) ?></strong></td>
          <td><?= htmlspecialchars($o['customer_name']) ?></td>
          <td><?= date('d M y, H:i', strtotime($o['created_at'])) ?></td>
          <td><strong>₹<?= number_format($o['total_amount'],2) ?></strong></td>
          <td><span class="status-badge pay-<?= $o['payment_status'] ?>"><?= ucfirst($o['payment_status']) ?></span></td>
          <td><span class="status-badge status-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
          <td><a href="order-detail.php?id=<?= $o['id'] ?>" class="btn btn-sm btn-dark">Manage</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php else: ?>
  <div class="empty-state"><div class="empty-icon">📭</div><h3>No orders yet</h3></div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>

<?php
require_once __DIR__ . '/../includes/functions.php';
if (isAdminLoggedIn()) { header('Location: ' . SITE_URL . '/admin/dashboard.php'); exit; }

$legacyDefaultHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$username || !$password) {
        $error = 'Please enter username and password.';
    } else {
        $pdo  = getDB();
        $stmt = $pdo->prepare('SELECT * FROM admins WHERE username = ?');
        $stmt->execute([$username]);
        $admin = $stmt->fetch();
        $validPassword = false;

        if ($admin) {
            $storedPassword = (string) $admin['password_hash'];
            $hashInfo = password_get_info($storedPassword);
            $storedPasswordIsHash = !empty($hashInfo['algo']);

            if ($storedPasswordIsHash) {
                $validPassword = password_verify($password, $storedPassword);

                if ($validPassword && password_needs_rehash($storedPassword, PASSWORD_DEFAULT)) {
                    $newHash = password_hash($password, PASSWORD_DEFAULT);
                    $update = $pdo->prepare('UPDATE admins SET password_hash = ? WHERE id = ?');
                    $update->execute([$newHash, $admin['id']]);
                }
            } else {
                $shouldRepairDefault = $username === 'admin' && $password === 'admin123';
                $shouldMigratePlainText = hash_equals($storedPassword, $password);

                if ($shouldRepairDefault || $shouldMigratePlainText) {
                    $newHash = password_hash($password, PASSWORD_DEFAULT);
                    $update = $pdo->prepare('UPDATE admins SET password_hash = ? WHERE id = ?');
                    $update->execute([$newHash, $admin['id']]);
                    $validPassword = true;
                }
            }

            if (!$validPassword
                && $username === 'admin'
                && $password === 'admin123'
                && hash_equals($legacyDefaultHash, $storedPassword)
            ) {
                $newHash = password_hash($password, PASSWORD_DEFAULT);
                $update = $pdo->prepare('UPDATE admins SET password_hash = ? WHERE id = ?');
                $update->execute([$newHash, $admin['id']]);
                $validPassword = true;
            }
        }

        if ($validPassword) {
            session_regenerate_id(true);
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_user'] = $admin['username'];
            header('Location: ' . SITE_URL . '/admin/dashboard.php');
            exit;
        } else {
            $error = 'Invalid username or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login — eSolar</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= SITE_URL ?>/admin/admin.css">
</head>
<body>
<div class="admin-login-page">
  <div class="admin-login-card">
    <div style="text-align:center;margin-bottom:1.5rem">
      <div style="font-size:3rem;margin-bottom:.5rem">☀</div>
      <h2 style="font-size:1.5rem;margin-bottom:.2rem">eSolar Admin</h2>
      <p style="color:var(--gray-500);font-size:.88rem">Sign in to manage your store</p>
    </div>

    <?php if ($error): ?>
      <div class="flash flash-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group" style="margin-bottom:1rem">
        <label>Username</label>
        <input type="text" name="username" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" placeholder="admin" required autofocus>
      </div>
      <div class="form-group" style="margin-bottom:1.25rem">
        <label>Password</label>
        <input type="password" name="password" placeholder="Your password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-full">Login to Admin Panel →</button>
    </form>
    <div style="text-align:center;margin-top:1.25rem;font-size:.8rem;color:var(--gray-500)">
      Default: <code>admin</code> / <code>admin123</code>
    </div>
  </div>
</div>
</body>
</html>

<?php
$pageTitle = 'Order Detail';
require_once __DIR__ . '/admin-header.php';
$pdo = getDB();

$oid = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT o.*, c.name AS cname, c.email AS cemail, c.phone AS cphone, py.transaction_id, py.card_last4, py.card_type, py.paid_at FROM orders o JOIN customers c ON c.id = o.customer_id LEFT JOIN payments py ON py.order_id = o.id WHERE o.id = ?');
$stmt->execute([$oid]);
$order = $stmt->fetch();
if (!$order) { flash('error', 'Order not found.'); header('Location: orders.php'); exit; }

$items = $pdo->prepare('SELECT oi.*, p.name AS pname, p.brand FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ?');
$items->execute([$oid]);
$items = $items->fetchAll();

$statuses = ['pending','confirmed','processing','shipped','delivered','cancelled'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$_POST['status'], $oid]);
    flash('success', 'Order status updated.');
    header('Location: order-detail.php?id=' . $oid);
    exit;
}
?>

<div style="display:flex;gap:.75rem;margin-bottom:1.5rem;flex-wrap:wrap">
  <a href="orders.php" class="btn btn-outline btn-sm">← Back to Orders</a>
  <span style="font-size:1rem;font-weight:700;color:var(--solar-orange);align-self:center"><?= htmlspecialchars($order['order_number']) ?></span>
  <span class="status-badge status-<?= $order['status'] ?>" style="align-self:center;font-size:.82rem"><?= ucfirst($order['status']) ?></span>
</div>

<div style="display:grid;grid-template-columns:1fr 340px;gap:1.25rem;align-items:start">
  <div>
    <!-- Items -->
    <div class="card mb-2">
      <h3 style="margin-bottom:1rem">Order Items</h3>
      <div class="table-wrap" style="box-shadow:none">
        <table>
          <thead><tr><th>Product</th><th>Brand</th><th>Qty</th><th>Unit Price</th><th>Subtotal</th></tr></thead>
          <tbody>
            <?php foreach ($items as $it): ?>
            <tr>
              <td><?= htmlspecialchars($it['pname']) ?></td>
              <td><?= htmlspecialchars($it['brand'] ?? '—') ?></td>
              <td><?= $it['quantity'] ?></td>
              <td>₹<?= number_format($it['unit_price'], 2) ?></td>
              <td><strong>₹<?= number_format($it['subtotal'], 2) ?></strong></td>
            </tr>
            <?php endforeach; ?>
            <tr style="font-weight:700;background:var(--gray-100)">
              <td colspan="4" style="text-align:right">Order Total</td>
              <td style="color:var(--solar-orange)">₹<?= number_format($order['total_amount'], 2) ?></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Customer -->
    <div class="card mb-2">
      <h3 style="margin-bottom:1rem">Customer Info</h3>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
        <div><div class="text-muted" style="font-size:.75rem">Name</div><strong><?= htmlspecialchars($order['cname']) ?></strong></div>
        <div><div class="text-muted" style="font-size:.75rem">Email</div><strong><?= htmlspecialchars($order['cemail']) ?></strong></div>
        <div><div class="text-muted" style="font-size:.75rem">Phone</div><strong><?= htmlspecialchars($order['cphone'] ?? '—') ?></strong></div>
      </div>
    </div>

    <!-- Payment -->
    <div class="card">
      <h3 style="margin-bottom:1rem">Payment Info</h3>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem">
        <div><div class="text-muted" style="font-size:.75rem">Transaction ID</div><strong><?= htmlspecialchars($order['transaction_id'] ?? 'N/A') ?></strong></div>
        <div><div class="text-muted" style="font-size:.75rem">Method</div><strong><?= ucfirst(htmlspecialchars($order['payment_method'])) ?></strong></div>
        <div><div class="text-muted" style="font-size:.75rem">Status</div><span class="status-badge pay-<?= $order['payment_status'] ?>"><?= ucfirst($order['payment_status']) ?></span></div>
        <?php if ($order['card_last4']): ?>
        <div><div class="text-muted" style="font-size:.75rem">Card</div><strong><?= htmlspecialchars($order['card_type']) ?> •••• <?= $order['card_last4'] ?></strong></div>
        <?php endif; ?>
        <?php if ($order['paid_at']): ?>
        <div><div class="text-muted" style="font-size:.75rem">Paid At</div><strong><?= date('d M Y H:i', strtotime($order['paid_at'])) ?></strong></div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Sidebar -->
  <div>
    <!-- Update Status -->
    <div class="card mb-2">
      <h4 style="margin-bottom:1rem">Update Order Status</h4>
      <form method="POST">
        <div class="form-group" style="margin-bottom:.75rem">
          <select name="status">
            <?php foreach ($statuses as $s): ?>
            <option value="<?= $s ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <button type="submit" class="btn btn-success btn-full">✓ Update Status</button>
      </form>
    </div>

    <!-- Shipping Address -->
    <div class="card mb-2">
      <h4 style="margin-bottom:.75rem">Shipping Address</h4>
      <p style="font-size:.85rem;white-space:pre-wrap;color:var(--gray-700)"><?= htmlspecialchars($order['shipping_address']) ?></p>
    </div>

    <?php if ($order['notes']): ?>
    <div class="card">
      <h4 style="margin-bottom:.5rem">Order Notes</h4>
      <p style="font-size:.85rem;color:var(--gray-700)"><?= htmlspecialchars($order['notes']) ?></p>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>

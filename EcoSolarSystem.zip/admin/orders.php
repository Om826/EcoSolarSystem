<?php
$pageTitle = 'Orders';
require_once __DIR__ . '/admin-header.php';
$pdo = getDB();

// Update order status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $oid    = (int)$_POST['order_id'];
    $status = $_POST['status'];
    $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?')->execute([$status, $oid]);
    flash('success', 'Order status updated.');
    header('Location: orders.php' . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : ''));
    exit;
}

// Filters
$status  = $_GET['status'] ?? '';
$search  = trim($_GET['q'] ?? '');
$from    = $_GET['from'] ?? '';
$to      = $_GET['to'] ?? '';
$where   = [];
$params  = [];

if ($status) { $where[] = 'o.status = ?'; $params[] = $status; }
if ($search) { $where[] = '(o.order_number LIKE ? OR c.name LIKE ? OR c.email LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; }
if ($from)   { $where[] = 'DATE(o.created_at) >= ?'; $params[] = $from; }
if ($to)     { $where[] = 'DATE(o.created_at) <= ?'; $params[] = $to; }

$wSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$orders = $pdo->prepare("SELECT o.*, c.name AS cname, c.email AS cemail FROM orders o JOIN customers c ON c.id = o.customer_id $wSql ORDER BY o.created_at DESC");
$orders->execute($params);
$orders = $orders->fetchAll();

$statuses = ['pending','confirmed','processing','shipped','delivered','cancelled'];
?>

<!-- Filters -->
<form method="GET" class="filter-bar">
  <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Order # or customer…" style="flex:1;min-width:160px">
  <select name="status">
    <option value="">All Statuses</option>
    <?php foreach ($statuses as $s): ?>
    <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
    <?php endforeach; ?>
  </select>
  <input type="date" name="from" value="<?= htmlspecialchars($from) ?>" title="From date">
  <input type="date" name="to"   value="<?= htmlspecialchars($to) ?>"   title="To date">
  <button type="submit" class="btn btn-primary btn-sm">Filter</button>
  <a href="orders.php" class="btn btn-outline btn-sm">Reset</a>
</form>

<div style="font-size:.82rem;color:var(--gray-500);margin-bottom:.75rem"><?= count($orders) ?> order(s) found</div>

<div class="table-wrap">
  <table>
    <thead>
      <tr><th>Order #</th><th>Customer</th><th>Date</th><th>Amount</th><th>Payment</th><th>Status</th><th>Update Status</th><th>Detail</th></tr>
    </thead>
    <tbody>
      <?php if (empty($orders)): ?>
      <tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--gray-500)">No orders found.</td></tr>
      <?php endif; ?>
      <?php foreach ($orders as $o): ?>
      <tr>
        <td><strong style="color:var(--solar-orange)"><?= htmlspecialchars($o['order_number']) ?></strong></td>
        <td>
          <strong><?= htmlspecialchars($o['cname']) ?></strong><br>
          <span style="font-size:.75rem;color:var(--gray-500)"><?= htmlspecialchars($o['cemail']) ?></span>
        </td>
        <td><?= date('d M y, H:i', strtotime($o['created_at'])) ?></td>
        <td><strong>₹<?= number_format($o['total_amount'], 2) ?></strong></td>
        <td><span class="status-badge pay-<?= $o['payment_status'] ?>"><?= ucfirst($o['payment_status']) ?></span></td>
        <td><span class="status-badge status-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
        <td>
          <form method="POST" style="display:flex;gap:.4rem;align-items:center">
            <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
            <select name="status" style="padding:.3rem .5rem;border:1.5px solid var(--gray-200);border-radius:6px;font-size:.78rem">
              <?php foreach ($statuses as $s): ?>
              <option value="<?= $s ?>" <?= $o['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" name="update_status" class="btn btn-sm btn-success">✓</button>
          </form>
        </td>
        <td><a href="order-detail.php?id=<?= $o['id'] ?>" class="btn btn-sm btn-dark">View</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>

<?php
$pageTitle = 'Add Product';
require_once __DIR__ . '/admin-header.php';
$pdo = getDB();
$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name      = trim($_POST['name'] ?? '');
    $catId     = (int)($_POST['category_id'] ?? 0);
    $price     = (float)($_POST['price'] ?? 0);
    $stock     = (int)($_POST['stock'] ?? 0);
    $brand     = trim($_POST['brand'] ?? '');
    $wattage   = trim($_POST['wattage'] ?? '');
    $warranty  = trim($_POST['warranty'] ?? '');
    $desc      = trim($_POST['description'] ?? '');
    $isActive  = isset($_POST['is_active']) ? 1 : 0;

    if (!$name)   $errors[] = 'Product name is required.';
    if (!$catId)  $errors[] = 'Please select a category.';
    if ($price <= 0) $errors[] = 'Price must be greater than 0.';

    if (empty($errors)) {
        // Slug
        $slug = strtolower(preg_replace('/[^a-z0-9]+/', '-', $name));
        $slug = trim($slug, '-');
        // Ensure unique
        $chk = $pdo->prepare('SELECT id FROM products WHERE slug = ?');
        $chk->execute([$slug]);
        if ($chk->fetch()) $slug .= '-' . time();

        $stmt = $pdo->prepare('INSERT INTO products (category_id,name,slug,description,price,stock,brand,wattage,warranty,is_active) VALUES (?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute([$catId,$name,$slug,$desc,$price,$stock,$brand,$wattage,$warranty,$isActive]);
        flash('success', 'Product "' . $name . '" added successfully!');
        header('Location: products.php');
        exit;
    }
}
?>

<?php if (!empty($errors)): ?>
<div class="flash flash-error"><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div>
<?php endif; ?>

<div class="card">
  <form method="POST">
    <div class="form-grid">
      <div class="form-group form-full">
        <label>Product Name *</label>
        <input type="text" name="name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" placeholder="e.g. SunPower 400W Monocrystalline Panel" required>
      </div>
      <div class="form-group">
        <label>Category *</label>
        <select name="category_id" required>
          <option value="">— Select Category —</option>
          <?php foreach ($categories as $c): ?>
          <option value="<?= $c['id'] ?>" <?= ($_POST['category_id'] ?? '') == $c['id'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($c['name']) ?>
          </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Brand</label>
        <input type="text" name="brand" value="<?= htmlspecialchars($_POST['brand'] ?? '') ?>" placeholder="e.g. Luminous, Adani Solar">
      </div>
      <div class="form-group">
        <label>Price (₹) *</label>
        <input type="number" name="price" value="<?= htmlspecialchars($_POST['price'] ?? '') ?>" placeholder="e.g. 18500" step="0.01" min="0" required>
      </div>
      <div class="form-group">
        <label>Stock Quantity *</label>
        <input type="number" name="stock" value="<?= htmlspecialchars($_POST['stock'] ?? '0') ?>" min="0" required>
      </div>
      <div class="form-group">
        <label>Wattage / Capacity</label>
        <input type="text" name="wattage" value="<?= htmlspecialchars($_POST['wattage'] ?? '') ?>" placeholder="e.g. 400W, 150Ah, 200L">
      </div>
      <div class="form-group">
        <label>Warranty</label>
        <input type="text" name="warranty" value="<?= htmlspecialchars($_POST['warranty'] ?? '') ?>" placeholder="e.g. 5 years">
      </div>
      <div class="form-group form-full">
        <label>Description</label>
        <textarea name="description" rows="4" placeholder="Detailed product description…"><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
      </div>
      <div class="form-group">
        <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer">
          <input type="checkbox" name="is_active" value="1" <?= isset($_POST['is_active']) || !isset($_POST['name']) ? 'checked' : '' ?>>
          Active (visible on store)
        </label>
      </div>
    </div>

    <div style="display:flex;gap:1rem;margin-top:1.5rem">
      <button type="submit" class="btn btn-primary">➕ Add Product</button>
      <a href="products.php" class="btn btn-outline">Cancel</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>

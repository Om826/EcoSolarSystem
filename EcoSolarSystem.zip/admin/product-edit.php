<?php
$pageTitle = 'Edit Product';
require_once __DIR__ . '/admin-header.php';
$pdo = getDB();

$pid = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
$stmt->execute([$pid]);
$product = $stmt->fetch();
if (!$product) { flash('error', 'Product not found.'); header('Location: products.php'); exit; }

$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $catId    = (int)($_POST['category_id'] ?? 0);
    $price    = (float)($_POST['price'] ?? 0);
    $stock    = (int)($_POST['stock'] ?? 0);
    $brand    = trim($_POST['brand'] ?? '');
    $wattage  = trim($_POST['wattage'] ?? '');
    $warranty = trim($_POST['warranty'] ?? '');
    $desc     = trim($_POST['description'] ?? '');
    $isActive = isset($_POST['is_active']) ? 1 : 0;

    if (!$name)      $errors[] = 'Product name is required.';
    if (!$catId)     $errors[] = 'Please select a category.';
    if ($price <= 0) $errors[] = 'Price must be greater than 0.';

    if (empty($errors)) {
        $upd = $pdo->prepare('UPDATE products SET category_id=?,name=?,description=?,price=?,stock=?,brand=?,wattage=?,warranty=?,is_active=? WHERE id=?');
        $upd->execute([$catId,$name,$desc,$price,$stock,$brand,$wattage,$warranty,$isActive,$pid]);
        flash('success', 'Product updated successfully!');
        header('Location: products.php');
        exit;
    }
    // Merge POST into product for re-display
    $product = array_merge($product, $_POST);
}
?>

<?php if (!empty($errors)): ?>
<div class="flash flash-error"><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-header">
    <h3>Editing: <?= htmlspecialchars($product['name']) ?></h3>
    <a href="products.php" class="btn btn-sm btn-outline">← Back to Products</a>
  </div>

  <form method="POST">
    <div class="form-grid">
      <div class="form-group form-full">
        <label>Product Name *</label>
        <input type="text" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>
      </div>
      <div class="form-group">
        <label>Category *</label>
        <select name="category_id" required>
          <option value="">— Select Category —</option>
          <?php foreach ($categories as $c): ?>
          <option value="<?= $c['id'] ?>" <?= $product['category_id'] == $c['id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Brand</label>
        <input type="text" name="brand" value="<?= htmlspecialchars($product['brand'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Price (₹) *</label>
        <input type="number" name="price" value="<?= $product['price'] ?>" step="0.01" min="0" required>
      </div>
      <div class="form-group">
        <label>Stock Quantity</label>
        <input type="number" name="stock" value="<?= $product['stock'] ?>" min="0">
      </div>
      <div class="form-group">
        <label>Wattage / Capacity</label>
        <input type="text" name="wattage" value="<?= htmlspecialchars($product['wattage'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Warranty</label>
        <input type="text" name="warranty" value="<?= htmlspecialchars($product['warranty'] ?? '') ?>">
      </div>
      <div class="form-group form-full">
        <label>Description</label>
        <textarea name="description" rows="4"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
      </div>
      <div class="form-group">
        <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer">
          <input type="checkbox" name="is_active" value="1" <?= $product['is_active'] ? 'checked' : '' ?>>
          Active (visible on store)
        </label>
      </div>
    </div>
    <div style="display:flex;gap:1rem;margin-top:1.5rem">
      <button type="submit" class="btn btn-primary">💾 Save Changes</button>
      <a href="products.php" class="btn btn-outline">Cancel</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>

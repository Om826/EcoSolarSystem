<?php
$pageTitle = 'Products';
require_once __DIR__ . '/admin-header.php';
$pdo = getDB();

// Handle toggle active / delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $pid    = (int)($_POST['product_id'] ?? 0);

    if ($action === 'toggle' && $pid) {
        $pdo->prepare('UPDATE products SET is_active = NOT is_active WHERE id = ?')->execute([$pid]);
        flash('success', 'Product status updated.');
    } elseif ($action === 'delete' && $pid) {
        // Soft: just deactivate instead of hard delete to preserve order history
        $pdo->prepare('UPDATE products SET is_active = 0 WHERE id = ?')->execute([$pid]);
        flash('success', 'Product deactivated.');
    }
    header('Location: products.php');
    exit;
}

$cat   = $_GET['cat'] ?? '';
$search = trim($_GET['q'] ?? '');
$where  = [];
$params = [];

if ($cat)    { $where[] = 'p.category_id = ?'; $params[] = $cat; }
if ($search) { $where[] = '(p.name LIKE ? OR p.brand LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }

$wSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$stmt = $pdo->prepare("SELECT p.*, c.name AS cat_name FROM products p JOIN categories c ON c.id = p.category_id $wSql ORDER BY p.id DESC");
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
?>

<div class="card-header" style="margin-bottom:1.25rem">
  <div></div>
  <a href="product-add.php" class="btn btn-primary">➕ Add New Product</a>
</div>

<!-- Filters -->
<form method="GET" class="filter-bar">
  <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search products…" style="flex:1;min-width:180px">
  <select name="cat">
    <option value="">All Categories</option>
    <?php foreach ($categories as $c): ?>
    <option value="<?= $c['id'] ?>" <?= $cat == $c['id'] ? 'selected' : '' ?>><?= htmlspecialchars($c['name']) ?></option>
    <?php endforeach; ?>
  </select>
  <button type="submit" class="btn btn-primary btn-sm">Filter</button>
  <a href="products.php" class="btn btn-outline btn-sm">Reset</a>
</form>

<div class="table-wrap">
  <table>
    <thead>
      <tr><th>#</th><th>Name</th><th>Category</th><th>Brand</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr>
    </thead>
    <tbody>
      <?php if (empty($products)): ?>
      <tr><td colspan="8" style="text-align:center;padding:2rem;color:var(--gray-500)">No products found.</td></tr>
      <?php endif; ?>
      <?php foreach ($products as $p): ?>
      <tr>
        <td style="color:var(--gray-500)"><?= $p['id'] ?></td>
        <td>
          <strong><?= htmlspecialchars($p['name']) ?></strong>
          <?php if ($p['wattage']): ?><br><span style="font-size:.74rem;color:var(--gray-500)">⚡ <?= htmlspecialchars($p['wattage']) ?></span><?php endif; ?>
        </td>
        <td><?= htmlspecialchars($p['cat_name']) ?></td>
        <td><?= htmlspecialchars($p['brand'] ?? '—') ?></td>
        <td><strong>₹<?= number_format($p['price'], 2) ?></strong></td>
        <td>
          <span style="color:<?= $p['stock'] < 5 ? 'var(--danger)' : ($p['stock'] < 20 ? 'var(--warning)' : 'var(--success)') ?>;font-weight:600">
            <?= $p['stock'] ?>
          </span>
        </td>
        <td>
          <span class="status-badge <?= $p['is_active'] ? 'active-yes' : 'active-no' ?>">
            <?= $p['is_active'] ? 'Active' : 'Inactive' ?>
          </span>
        </td>
        <td>
          <div class="gap-1">
            <a href="product-edit.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline">✏️ Edit</a>
            <form method="POST" style="display:inline">
              <input type="hidden" name="action" value="toggle">
              <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
              <button type="submit" class="btn btn-sm <?= $p['is_active'] ? 'btn-dark' : 'btn-success' ?>">
                <?= $p['is_active'] ? '🙈 Hide' : '👁 Show' ?>
              </button>
            </form>
            <form method="POST" style="display:inline">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
              <button type="submit" class="btn btn-sm btn-danger" data-confirm="Deactivate this product?">🗑</button>
            </form>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>

<?php
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();
require_once __DIR__ . '/../includes/config.php';
$pdo = getDB();

// ── CSV Export ────────────────────────────────
if (isset($_GET['export'])) {
    $type = $_GET['export'];
    $from = $_GET['from'] ?? date('Y-01-01');
    $to   = $_GET['to']   ?? date('Y-m-d');

    ob_clean();
    header('Content-Type: text/csv; charset=utf-8');

    if ($type === 'orders') {
        header('Content-Disposition: attachment; filename="esolar_orders_' . date('Ymd') . '.csv"');
        $rows = $pdo->prepare("SELECT o.order_number, c.name, c.email, c.phone, o.total_amount, o.payment_method, o.payment_status, o.status, o.created_at FROM orders o JOIN customers c ON c.id = o.customer_id WHERE DATE(o.created_at) BETWEEN ? AND ? ORDER BY o.created_at DESC");
        $rows->execute([$from, $to]);
        $out = fopen('php://output','w');
        fputcsv($out, ['Order Number','Customer','Email','Phone','Amount (₹)','Payment Method','Payment Status','Order Status','Date']);
        while ($r = $rows->fetch()) fputcsv($out, $r);
        fclose($out);
        exit;
    }

    if ($type === 'products') {
        header('Content-Disposition: attachment; filename="esolar_products_' . date('Ymd') . '.csv"');
        $rows = $pdo->query("SELECT p.id, p.name, c.name AS category, p.brand, p.price, p.stock, p.wattage, p.warranty, IF(p.is_active,'Active','Inactive') AS status FROM products p JOIN categories c ON c.id = p.category_id ORDER BY p.id");
        $out = fopen('php://output','w');
        fputcsv($out, ['ID','Product Name','Category','Brand','Price (₹)','Stock','Wattage','Warranty','Status']);
        while ($r = $rows->fetch()) fputcsv($out, $r);
        fclose($out);
        exit;
    }

    if ($type === 'customers') {
        header('Content-Disposition: attachment; filename="esolar_customers_' . date('Ymd') . '.csv"');
        $rows = $pdo->query("SELECT c.id, c.name, c.email, c.phone, c.city, c.state, COUNT(o.id) AS orders, COALESCE(SUM(o.total_amount),0) AS spent, c.created_at FROM customers c LEFT JOIN orders o ON o.customer_id=c.id GROUP BY c.id ORDER BY c.created_at DESC");
        $out = fopen('php://output','w');
        fputcsv($out, ['ID','Name','Email','Phone','City','State','Total Orders','Total Spent (₹)','Joined']);
        while ($r = $rows->fetch()) fputcsv($out, $r);
        fclose($out);
        exit;
    }
}

$pageTitle = 'Reports';
require_once __DIR__ . '/admin-header.php';

// Date range
$from = $_GET['from'] ?? date('Y-01-01');
$to   = $_GET['to']   ?? date('Y-m-d');

// Summary stats for range
$rev    = $pdo->prepare("SELECT COALESCE(SUM(total_amount),0) FROM orders WHERE payment_status='paid' AND DATE(created_at) BETWEEN ? AND ?"); $rev->execute([$from,$to]); $revenue = $rev->fetchColumn();
$ords   = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE DATE(created_at) BETWEEN ? AND ?"); $ords->execute([$from,$to]); $ordCount = $ords->fetchColumn();
$cust   = $pdo->prepare("SELECT COUNT(DISTINCT customer_id) FROM orders WHERE DATE(created_at) BETWEEN ? AND ?"); $cust->execute([$from,$to]); $custCount = $cust->fetchColumn();
$avg    = $ordCount > 0 ? $revenue / $ordCount : 0;

// Monthly breakdown
$monthly = $pdo->prepare("SELECT DATE_FORMAT(created_at,'%b %Y') AS month, MIN(created_at) AS month_sort, COUNT(*) AS orders, SUM(total_amount) AS revenue, SUM(CASE WHEN payment_status='paid' THEN total_amount ELSE 0 END) AS paid_revenue FROM orders WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY DATE_FORMAT(created_at,'%Y-%m') ORDER BY month_sort");
$monthly->execute([$from,$to]); $monthly = $monthly->fetchAll();

// Orders by status
$byStatus = $pdo->prepare("SELECT status, COUNT(*) AS cnt FROM orders WHERE DATE(created_at) BETWEEN ? AND ? GROUP BY status ORDER BY cnt DESC");
$byStatus->execute([$from,$to]); $byStatus = $byStatus->fetchAll();

// Top products
$topProds = $pdo->prepare("SELECT p.name, p.brand, SUM(oi.quantity) AS qty, SUM(oi.subtotal) AS revenue FROM order_items oi JOIN products p ON p.id=oi.product_id JOIN orders o ON o.id=oi.order_id WHERE DATE(o.created_at) BETWEEN ? AND ? GROUP BY oi.product_id ORDER BY revenue DESC LIMIT 10");
$topProds->execute([$from,$to]); $topProds = $topProds->fetchAll();

// Top categories
$topCats = $pdo->prepare("SELECT c.name, SUM(oi.quantity) AS qty, SUM(oi.subtotal) AS revenue FROM order_items oi JOIN products p ON p.id=oi.product_id JOIN categories c ON c.id=p.category_id JOIN orders o ON o.id=oi.order_id WHERE DATE(o.created_at) BETWEEN ? AND ? GROUP BY p.category_id ORDER BY revenue DESC");
$topCats->execute([$from,$to]); $topCats = $topCats->fetchAll();
?>

<!-- Date Range Filter -->
<form method="GET" class="filter-bar" style="margin-bottom:1.5rem">
  <label style="font-size:.82rem;font-weight:600">From:</label>
  <input type="date" name="from" value="<?= $from ?>">
  <label style="font-size:.82rem;font-weight:600">To:</label>
  <input type="date" name="to" value="<?= $to ?>">
  <button type="submit" class="btn btn-primary btn-sm">📊 Generate Report</button>
  <a href="?from=<?= date('Y-m-01') ?>&to=<?= date('Y-m-d') ?>" class="btn btn-outline btn-sm">This Month</a>
  <a href="?from=<?= date('Y-01-01') ?>&to=<?= date('Y-m-d') ?>" class="btn btn-outline btn-sm">This Year</a>
</form>

<!-- Export Buttons -->
<div style="display:flex;gap:.75rem;flex-wrap:wrap;margin-bottom:1.5rem">
  <strong style="align-self:center;font-size:.85rem">Export CSV:</strong>
  <a href="?export=orders&from=<?= $from ?>&to=<?= $to ?>" class="btn btn-sm btn-success">📥 Orders</a>
  <a href="?export=products" class="btn btn-sm btn-dark">📥 Products</a>
  <a href="?export=customers" class="btn btn-sm btn-dark">📥 Customers</a>
</div>

<!-- Summary Cards -->
<div class="report-grid mb-3">
  <div class="report-card">
    <div class="big-num">₹<?= number_format($revenue/1000, 1) ?>K</div>
    <div class="rcard-label">Revenue (Paid)</div>
  </div>
  <div class="report-card">
    <div class="big-num"><?= $ordCount ?></div>
    <div class="rcard-label">Total Orders</div>
  </div>
  <div class="report-card">
    <div class="big-num"><?= $custCount ?></div>
    <div class="rcard-label">Unique Customers</div>
  </div>
  <div class="report-card">
    <div class="big-num">₹<?= number_format($avg, 0) ?></div>
    <div class="rcard-label">Avg Order Value</div>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:1.25rem">
  <!-- Monthly Revenue -->
  <div class="card">
    <div class="card-header"><h3>Monthly Revenue</h3></div>
    <?php if ($monthly): ?>
    <div class="table-wrap" style="box-shadow:none">
      <table>
        <thead><tr><th>Month</th><th>Orders</th><th>Revenue</th><th>Paid Revenue</th></tr></thead>
        <tbody>
          <?php foreach ($monthly as $m): ?>
          <tr>
            <td><?= htmlspecialchars($m['month']) ?></td>
            <td><?= $m['orders'] ?></td>
            <td>₹<?= number_format($m['revenue'],2) ?></td>
            <td style="color:var(--success);font-weight:600">₹<?= number_format($m['paid_revenue'],2) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?><div class="empty-state"><div class="empty-icon">📅</div><p>No data for selected range.</p></div><?php endif; ?>
  </div>

  <!-- Orders by Status -->
  <div class="card">
    <div class="card-header"><h3>Orders by Status</h3></div>
    <?php if ($byStatus): ?>
    <?php foreach ($byStatus as $s): ?>
    <div style="display:flex;align-items:center;justify-content:space-between;padding:.5rem 0;border-bottom:1px solid var(--gray-100)">
      <span class="status-badge status-<?= $s['status'] ?>"><?= ucfirst($s['status']) ?></span>
      <strong style="font-size:1.1rem"><?= $s['cnt'] ?></strong>
    </div>
    <?php endforeach; ?>
    <?php else: ?><div class="empty-state"><div class="empty-icon">📦</div><p>No orders.</p></div><?php endif; ?>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem">
  <!-- Top Products -->
  <div class="card">
    <div class="card-header"><h3>Top 10 Products by Revenue</h3></div>
    <?php if ($topProds): ?>
    <div class="table-wrap" style="box-shadow:none">
      <table>
        <thead><tr><th>Product</th><th>Qty Sold</th><th>Revenue</th></tr></thead>
        <tbody>
          <?php foreach ($topProds as $tp): ?>
          <tr>
            <td>
              <?= htmlspecialchars(substr($tp['name'],0,30)) ?>…<br>
              <span style="font-size:.73rem;color:var(--gray-500)"><?= htmlspecialchars($tp['brand'] ?? '') ?></span>
            </td>
            <td><?= $tp['qty'] ?></td>
            <td style="font-weight:700;color:var(--solar-orange)">₹<?= number_format($tp['revenue'],0) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?><div class="empty-state"><div class="empty-icon">🌞</div><p>No sales yet.</p></div><?php endif; ?>
  </div>

  <!-- Category Performance -->
  <div class="card">
    <div class="card-header"><h3>Revenue by Category</h3></div>
    <?php if ($topCats): ?>
    <?php
    $maxCat = max(array_column($topCats,'revenue')) ?: 1;
    foreach ($topCats as $tc):
      $pct = round(($tc['revenue']/$maxCat)*100);
    ?>
    <div style="margin-bottom:1rem">
      <div style="display:flex;justify-content:space-between;margin-bottom:.3rem;font-size:.85rem">
        <span><?= htmlspecialchars($tc['name']) ?></span>
        <strong style="color:var(--solar-orange)">₹<?= number_format($tc['revenue'],0) ?></strong>
      </div>
      <div style="background:var(--gray-100);border-radius:4px;height:8px">
        <div style="width:<?= $pct ?>%;background:var(--solar-orange);border-radius:4px;height:8px;transition:width .3s"></div>
      </div>
      <div style="font-size:.73rem;color:var(--gray-500);margin-top:.2rem"><?= $tc['qty'] ?> units sold</div>
    </div>
    <?php endforeach; ?>
    <?php else: ?><div class="empty-state"><div class="empty-icon">📊</div><p>No data yet.</p></div><?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/admin-footer.php'; ?>

// eSolar — Main JS

// Auto-hide flash messages after 4s
document.querySelectorAll('.flash').forEach(el => {
  setTimeout(() => {
    el.style.transition = 'opacity .5s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 500);
  }, 4000);
});

// Cart qty controls
document.querySelectorAll('.qty-btn').forEach(btn => {
  btn.addEventListener('click', function() {
    const input = this.closest('.qty-control').querySelector('.qty-input');
    let val = parseInt(input.value) || 1;
    if (this.dataset.action === 'inc') val++;
    if (this.dataset.action === 'dec') val = Math.max(1, val - 1);
    input.value = val;
  });
});

// Credit card live preview
const cardNum   = document.getElementById('card_number');
const cardName  = document.getElementById('card_holder');
const cardExp   = document.getElementById('expiry');
const previewNum  = document.getElementById('prev-num');
const previewName = document.getElementById('prev-name');
const previewExp  = document.getElementById('prev-exp');

if (cardNum && previewNum) {
  cardNum.addEventListener('input', function() {
    let v = this.value.replace(/\D/g,'').substring(0,16);
    this.value = v.replace(/(.{4})/g,'$1 ').trim();
    const last4 = v.substring(12) || '****';
    previewNum.textContent = '**** **** **** ' + last4.padEnd(4,'*');
  });
  cardName.addEventListener('input', function() {
    previewName.textContent = this.value.toUpperCase() || 'YOUR NAME';
  });
  cardExp.addEventListener('input', function() {
    let v = this.value.replace(/\D/g,'').substring(0,4);
    if (v.length >= 2) v = v.substring(0,2) + '/' + v.substring(2);
    this.value = v;
    previewExp.textContent = v || 'MM/YY';
  });
}

// Confirm delete
document.querySelectorAll('[data-confirm]').forEach(el => {
  el.addEventListener('click', function(e) {
    if (!confirm(this.dataset.confirm || 'Are you sure?')) e.preventDefault();
  });
});

// Admin sidebar active link
document.querySelectorAll('.admin-nav a').forEach(link => {
  if (link.href === window.location.href) link.classList.add('active');
});

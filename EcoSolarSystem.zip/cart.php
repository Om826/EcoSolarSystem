<?php
require_once 'includes/functions.php';
$pageTitle = 'Your Cart';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $pid    = (int)($_POST['product_id'] ?? 0);

    if ($action === 'remove') {
        removeFromCart($pid);
        flash('success', 'Item removed from cart.');
    } elseif ($action === 'update') {
        updateCartQty($pid, (int)($_POST['qty'] ?? 1));
        flash('success', 'Cart updated.');
    } elseif ($action === 'clear') {
        clearCart();
        flash('success', 'Cart cleared.');
    }
    header('Location: cart.php');
    exit;
}

$cart  = getCart();
$total = cartTotal();
$icons = ['solar-panels'=>'🌞','solar-inverters'=>'⚡','solar-batteries'=>'🔋','solar-water-heaters'=>'🚿'];

// Enrich cart with category icons
$pdo = getDB();
foreach ($cart as $pid => &$item) {
    $st = $pdo->prepare('SELECT c.slug FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ?');
    $st->execute([$pid]);
    $row = $st->fetch();
    $item['icon'] = $row ? ($icons[$row['slug']] ?? '☀️') : '☀️';
}
unset($item);

include 'includes/header.php';
?>

<div class="page-header">
  <div class="container">
    <div class="breadcrumb"><a href="<?= SITE_URL ?>">Home</a> › Cart</div>
    <h1>Shopping Cart <?php if ($cart): ?><span style="font-size:1rem;color:var(--solar-orange);font-weight:400">(<?= cartCount() ?> items)</span><?php endif; ?></h1>
  </div>
</div>

<div class="container" style="padding-bottom:3rem">
  <?php if (empty($cart)): ?>
  <div class="empty-state">
    <div class="empty-icon">🛒</div>
    <h3>Your cart is empty</h3>
    <p>Add some solar products to get started!</p>
    <a href="products.php" class="btn btn-primary mt-2">Browse Products</a>
  </div>
  <?php else: ?>
  <div class="cart-layout">
    <!-- Items -->
    <div>
      <?php foreach ($cart as $pid => $item): ?>
      <div class="cart-item">
        <div class="cart-item-img"><?= $item['icon'] ?></div>
        <div>
          <div class="cart-item-name"><?= sanitize($item['name']) ?></div>
          <div class="cart-item-price"><?= formatPrice($item['price']) ?> each</div>
          <form method="POST" class="qty-control">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="product_id" value="<?= $pid ?>">
            <button type="button" class="qty-btn" data-action="dec">−</button>
            <input type="number" name="qty" class="qty-input" value="<?= $item['qty'] ?>" min="1" max="50">
            <button type="button" class="qty-btn" data-action="inc">+</button>
            <button type="submit" class="btn btn-outline btn-sm">Update</button>
          </form>
        </div>
        <div style="text-align:right">
          <div style="font-family:'Syne',sans-serif;font-size:1.1rem;font-weight:700;color:var(--navy)"><?= formatPrice($item['price'] * $item['qty']) ?></div>
          <form method="POST" style="margin-top:.5rem">
            <input type="hidden" name="action" value="remove">
            <input type="hidden" name="product_id" value="<?= $pid ?>">
            <button type="submit" class="btn btn-sm" style="background:#fee2e2;color:#991b1b;border:none">Remove</button>
          </form>
        </div>
      </div>
      <?php endforeach; ?>

      <div style="display:flex;gap:1rem;margin-top:1rem">
        <form method="POST">
          <input type="hidden" name="action" value="clear">
          <button type="submit" class="btn btn-outline btn-sm" data-confirm="Clear entire cart?">🗑 Clear Cart</button>
        </form>
        <a href="products.php" class="btn btn-outline btn-sm">← Continue Shopping</a>
      </div>
    </div>

    <!-- Summary -->
    <div class="order-summary">
      <h3>Order Summary</h3>
      <?php foreach ($cart as $item): ?>
      <div class="summary-row">
        <span><?= sanitize(substr($item['name'],0,28)) ?>… × <?= $item['qty'] ?></span>
        <span><?= formatPrice($item['price'] * $item['qty']) ?></span>
      </div>
      <?php endforeach; ?>
      <div class="summary-row"><span>Subtotal</span><span><?= formatPrice($total) ?></span></div>
      <div class="summary-row"><span>Shipping</span><span><?= $total >= 10000 ? '<span style="color:var(--success)">FREE</span>' : formatPrice(500) ?></span></div>
      <div class="summary-row"><span>GST (18%)</span><span><?= formatPrice($total * 0.18) ?></span></div>
      <div class="summary-row total">
        <span>Total Payable</span>
        <span><?= formatPrice($total + ($total >= 10000 ? 0 : 500) + $total * 0.18) ?></span>
      </div>
      <a href="checkout.php" class="btn btn-primary btn-full" style="margin-top:1rem">Proceed to Checkout →</a>
      <div style="font-size:.78rem;color:var(--gray-500);text-align:center;margin-top:.75rem">🔒 Secure checkout. Free delivery on orders above ₹10,000.</div>
    </div>
  </div>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>

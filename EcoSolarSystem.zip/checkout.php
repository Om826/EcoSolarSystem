<?php
require_once 'includes/functions.php';
requireLogin();
$pageTitle = 'Checkout';

$cart = getCart();
if (empty($cart)) { header('Location: ' . SITE_URL . '/cart.php'); exit; }

$customer = currentCustomer();
$subtotal  = cartTotal();
$shipping  = $subtotal >= 10000 ? 0 : 500;
$gst       = round($subtotal * 0.18, 2);
$grandTotal = $subtotal + $shipping + $gst;

include 'includes/header.php';
?>

<div class="page-header">
  <div class="container">
    <div class="breadcrumb"><a href="<?= SITE_URL ?>">Home</a> › <a href="cart.php">Cart</a> › Checkout</div>
    <h1>Checkout</h1>
  </div>
</div>

<div class="container" style="padding-bottom:3rem">
  <div class="cart-layout">
    <!-- Shipping Address Form -->
    <div>
      <div class="card">
        <h3 style="margin-bottom:1.25rem;font-size:1.1rem">📦 Delivery Address</h3>
        <form method="POST" action="payment.php" id="checkoutForm">
          <input type="hidden" name="subtotal"   value="<?= $subtotal ?>">
          <input type="hidden" name="shipping"   value="<?= $shipping ?>">
          <input type="hidden" name="gst"        value="<?= $gst ?>">
          <input type="hidden" name="grand_total" value="<?= $grandTotal ?>">

          <div class="form-row">
            <div class="form-group">
              <label>Full Name *</label>
              <input type="text" name="ship_name" value="<?= sanitize($customer['name']) ?>" required>
            </div>
            <div class="form-group">
              <label>Phone *</label>
              <input type="text" name="ship_phone" value="<?= sanitize($customer['phone'] ?? '') ?>" required>
            </div>
          </div>
          <div class="form-group">
            <label>Street Address *</label>
            <textarea name="ship_address" rows="2" required><?= sanitize($customer['address'] ?? '') ?></textarea>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>City *</label>
              <input type="text" name="ship_city" value="<?= sanitize($customer['city'] ?? '') ?>" required>
            </div>
            <div class="form-group">
              <label>State *</label>
              <input type="text" name="ship_state" value="<?= sanitize($customer['state'] ?? '') ?>" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label>PIN Code *</label>
              <input type="text" name="ship_pincode" value="<?= sanitize($customer['pincode'] ?? '') ?>" required maxlength="6">
            </div>
            <div class="form-group"><!-- spacer --></div>
          </div>
          <div class="form-group">
            <label>Order Notes (optional)</label>
            <textarea name="notes" rows="2" placeholder="Any special instructions for delivery…"></textarea>
          </div>
          <button type="submit" class="btn btn-primary btn-full">Proceed to Payment →</button>
        </form>
      </div>
    </div>

    <!-- Order Summary -->
    <div class="order-summary">
      <h3>Your Order</h3>
      <?php foreach ($cart as $item): ?>
      <div class="summary-row">
        <span><?= sanitize(substr($item['name'],0,26)) ?>… × <?= $item['qty'] ?></span>
        <span><?= formatPrice($item['price'] * $item['qty']) ?></span>
      </div>
      <?php endforeach; ?>
      <div class="summary-row"><span>Subtotal</span><span><?= formatPrice($subtotal) ?></span></div>
      <div class="summary-row">
        <span>Shipping</span>
        <span><?= $shipping === 0 ? '<span style="color:var(--success)">FREE</span>' : formatPrice($shipping) ?></span>
      </div>
      <div class="summary-row"><span>GST (18%)</span><span><?= formatPrice($gst) ?></span></div>
      <div class="summary-row total">
        <span>Grand Total</span>
        <span><?= formatPrice($grandTotal) ?></span>
      </div>
      <div style="font-size:.78rem;color:var(--gray-500);margin-top:1rem;text-align:center">
        🔒 Safe & secure checkout<br>
        Next step: Payment
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>

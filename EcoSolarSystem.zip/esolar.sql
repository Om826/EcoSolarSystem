-- eSolar Database Schema
-- Run this file in phpMyAdmin or via: mysql -u root -p < esolar.sql

CREATE DATABASE IF NOT EXISTS esolar CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE esolar;

-- =====================
-- TABLES
-- =====================

CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(15),
    address TEXT,
    city VARCHAR(80),
    state VARCHAR(80),
    pincode VARCHAR(10),
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(60) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(10) DEFAULT '☀️'
);

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(200) NOT NULL,
    slug VARCHAR(200) NOT NULL UNIQUE,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL DEFAULT 0,
    image_url VARCHAR(255) DEFAULT '',
    wattage VARCHAR(50),
    warranty VARCHAR(50),
    brand VARCHAR(100),
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    order_number VARCHAR(20) NOT NULL UNIQUE,
    total_amount DECIMAL(10,2) NOT NULL,
    shipping_address TEXT NOT NULL,
    status ENUM('pending','confirmed','processing','shipped','delivered','cancelled') DEFAULT 'pending',
    payment_status ENUM('pending','paid','failed','refunded') DEFAULT 'pending',
    payment_method VARCHAR(50) DEFAULT 'card',
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL UNIQUE,
    card_holder_name VARCHAR(150),
    card_last4 VARCHAR(4),
    card_type VARCHAR(20),
    amount DECIMAL(10,2) NOT NULL,
    transaction_id VARCHAR(60),
    status ENUM('success','failed') DEFAULT 'success',
    paid_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

-- =====================
-- SEED DATA
-- =====================

-- Admin user (password: admin123)
INSERT INTO admins (username, password_hash) VALUES
('admin', '$2y$10$V6e3TP2AkH5i5jzkkNlALus2CenaAiqIrISr71xbdFOqrQCBJ4N0y');

-- Categories
INSERT INTO categories (name, slug, description, icon) VALUES
('Solar Panels',       'solar-panels',       'High-efficiency monocrystalline and polycrystalline solar panels for homes and businesses.', '🌞'),
('Solar Inverters',    'solar-inverters',    'String, hybrid, and micro-inverters to convert solar DC power into usable AC electricity.',   '⚡'),
('Solar Batteries',    'solar-batteries',    'Lithium-ion and lead-acid battery storage solutions for uninterrupted solar power supply.',    '🔋'),
('Solar Water Heaters','solar-water-heaters','Flat plate and evacuated tube solar water heating systems for residential use.',               '🚿');

-- Products — Solar Panels
INSERT INTO products (category_id, name, slug, description, price, stock, wattage, warranty, brand) VALUES
(1, 'SunPower 400W Monocrystalline Panel',   'sunpower-400w-mono',   'Premium monocrystalline panel with 21.4% efficiency. Ideal for rooftop installations with limited space.', 18500.00, 50, '400W', '25 years', 'SunPower'),
(1, 'Luminous 330W Polycrystalline Panel',   'luminous-330w-poly',   'Cost-effective polycrystalline panel suitable for large-scale residential and commercial setups.',         12800.00, 80, '330W', '20 years', 'Luminous'),
(1, 'Adani 545W HiMo6 Bifacial Panel',       'adani-545w-bifacial',  'High-wattage bifacial panel capturing energy from both sides. Best for ground-mounted systems.',          26500.00, 30, '545W', '25 years', 'Adani Solar'),
(1, 'Vikram Solar 250W Eldora Panel',        'vikram-250w-eldora',   'Entry-level panel perfect for small homes and backup applications. Easy to install.',                     9200.00, 120, '250W', '10 years', 'Vikram Solar');

-- Products — Solar Inverters
INSERT INTO products (category_id, name, slug, description, price, stock, wattage, warranty, brand) VALUES
(2, 'Solis 3kW String Inverter',             'solis-3kw-string',     'Single-phase string inverter with MPPT tracking. Compact design, suitable for 3kW rooftop systems.',      14500.00, 40, '3000W', '5 years',  'Solis'),
(2, 'Growatt 5kW Hybrid Inverter',           'growatt-5kw-hybrid',   'Hybrid inverter with built-in MPPT solar charger. Works with batteries for full off-grid capability.',    32000.00, 25, '5000W', '5 years',  'Growatt'),
(2, 'Luminous NXG+ 1450 Inverter',           'luminous-nxg-1450',    'Pure sine wave inverter/UPS combo. Ideal for small homes and backup power needs.',                        8500.00,  60, '1200W', '2 years',  'Luminous'),
(2, 'Havells Solgen 10kW Three Phase',       'havells-solgen-10kw',  '3-phase on-grid inverter for commercial rooftop solar plants. High conversion efficiency of 98.2%.',      55000.00, 15, '10000W','5 years',  'Havells');

-- Products — Solar Batteries
INSERT INTO products (category_id, name, slug, description, price, stock, wattage, warranty, brand) VALUES
(3, 'Luminous 150Ah Tubular Battery',        'luminous-150ah-tubular','Tall tubular battery designed for solar applications. Long backup and excellent deep discharge recovery.', 12500.00, 70, '150Ah', '5 years',  'Luminous'),
(3, 'Amaron 100Ah Solar Battery',            'amaron-100ah-solar',   'VRLA AGM battery with low self-discharge. Maintenance-free and spill-proof design.',                      9800.00,  55, '100Ah', '3 years',  'Amaron'),
(3, 'Livguard 200Ah Deep Cycle',             'livguard-200ah-deep',  'Heavy-duty deep cycle battery ideal for large solar installations and commercial use.',                    18000.00, 35, '200Ah', '5 years',  'Livguard'),
(3, 'Lithium Urban 5kWh LiFePO4 Pack',       'lithium-urban-5kwh',   'Lithium iron phosphate battery pack. Lightweight, 3000+ cycles, compatible with all hybrid inverters.',   85000.00, 12, '5kWh',  '10 years', 'Lithium Urban');

-- Products — Solar Water Heaters
INSERT INTO products (category_id, name, slug, description, price, stock, wattage, warranty, brand) VALUES
(4, 'V-Guard 100L ETC Water Heater',         'vguard-100l-etc',      'Evacuated tube collector system for 2–3 member families. Works even on cloudy days.',                     12000.00, 45, '100L',  '5 years',  'V-Guard'),
(4, 'Racold 200L FPC Solar Heater',          'racold-200l-fpc',      'Flat plate collector with twin-coil tank for hard water areas. Suitable for 4–5 members.',                22000.00, 30, '200L',  '7 years',  'Racold'),
(4, 'TATA Power Solar 300L Heater',          'tata-300l-heater',     'Large capacity ETC heater for joint families or guest houses. SS inner tank with 5-layer insulation.',    35000.00, 20, '300L',  '7 years',  'TATA Power'),
(4, 'Supreme 150L Compact Heater',           'supreme-150l-compact', 'Budget-friendly flat plate heater. Compact design for easy terrace installation. Includes backup heater.', 15500.00, 60, '150L',  '5 years',  'Supreme');

<footer class="site-footer">
  <div class="container-fluid footer-inner">
    <div class="footer-brand">
      <span class="logo-icon">☀</span>
      <span class="logo-text">e<strong>Solar</strong></span>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum voluptatem eveniet, quasi atque laudantium cum necessitatibus architecto perspiciatis aliquid nulla sapiente! Facilis numquam quisquam dolorum dignissimos doloribus eveniet repellat dolore!</p>
    </div>
    <div class="footer-links">
      <h4>Quick Links</h4>
      <a href="<?= SITE_URL ?>">Home</a>
      <a href="<?= SITE_URL ?>/products.php">All Products</a>
      <a href="<?= SITE_URL ?>/register.php">Register</a>
      <a href="<?= SITE_URL ?>/login.php">Login</a>
    </div>
    <div class="footer-links">
      <h4>Categories</h4>
      <a href="<?= SITE_URL ?>/products.php?cat=solar-panels">Solar Panels</a>
      <a href="<?= SITE_URL ?>/products.php?cat=solar-inverters">Inverters</a>
      <a href="<?= SITE_URL ?>/products.php?cat=solar-batteries">Batteries</a>
      <a href="<?= SITE_URL ?>/products.php?cat=solar-water-heaters">Water Heaters</a>
    </div>
    <div class="footer-links">
      <h4>Contact</h4>
      <p>📍 Wai, Maharashtra</p>
      <p>📞 +91 9373428808 / +91 8421950295</p>
      <p>📞 +91 7972696735 / +91 7249136022</p>
      <p>📧 info@esolar.in</p>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; <?= date('Y') ?> eSolar. All rights reserved. | Clean energy, brighter future.</p>
  </div>
</footer>
<script src="<?= SITE_URL ?>/assets/js/main.js"></script>
</body>
</html>

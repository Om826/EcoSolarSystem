<?php
// eSolar — Auth & Helper Functions

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/config.php';

// ── Customer Auth ──────────────────────────────────────────
function isLoggedIn(): bool {
    return isset($_SESSION['customer_id']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ' . SITE_URL . '/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}

function currentCustomer(): ?array {
    if (!isLoggedIn()) return null;
    $pdo = getDB();
    $stmt = $pdo->prepare('SELECT * FROM customers WHERE id = ?');
    $stmt->execute([$_SESSION['customer_id']]);
    return $stmt->fetch() ?: null;
}

// ── Admin Auth ─────────────────────────────────────────────
function isAdminLoggedIn(): bool {
    return isset($_SESSION['admin_id']);
}

function requireAdmin(): void {
    if (!isAdminLoggedIn()) {
        header('Location: ' . SITE_URL . '/admin/login.php');
        exit;
    }
}

// ── Cart Helpers ───────────────────────────────────────────
function getCart(): array {
    return $_SESSION['cart'] ?? [];
}

function cartCount(): int {
    $cart = getCart();
    return array_sum(array_column($cart, 'qty'));
}

function cartTotal(): float {
    $cart = getCart();
    return array_sum(array_map(fn($i) => $i['price'] * $i['qty'], $cart));
}

function addToCart(int $productId, int $qty = 1): void {
    $pdo = getDB();
    $stmt = $pdo->prepare('SELECT id, name, price, stock FROM products WHERE id = ? AND is_active = 1');
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    if (!$product) return;

    $cart = getCart();
    if (isset($cart[$productId])) {
        $cart[$productId]['qty'] = min($cart[$productId]['qty'] + $qty, $product['stock']);
    } else {
        $cart[$productId] = [
            'id'    => $product['id'],
            'name'  => $product['name'],
            'price' => (float)$product['price'],
            'qty'   => min($qty, $product['stock']),
        ];
    }
    $_SESSION['cart'] = $cart;
}

function removeFromCart(int $productId): void {
    unset($_SESSION['cart'][$productId]);
}

function updateCartQty(int $productId, int $qty): void {
    if ($qty <= 0) { removeFromCart($productId); return; }
    if (isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId]['qty'] = $qty;
    }
}

function clearCart(): void {
    $_SESSION['cart'] = [];
}

// ── Utilities ──────────────────────────────────────────────
function formatPrice(float $amount): string {
    return CURRENCY . number_format($amount, 2);
}

function generateOrderNumber(): string {
    return 'ESL-' . strtoupper(substr(uniqid(), -6)) . '-' . date('Ymd');
}

function flash(string $key, string $msg): void {
    $_SESSION['flash'][$key] = $msg;
}

function getFlash(string $key): ?string {
    $msg = $_SESSION['flash'][$key] ?? null;
    unset($_SESSION['flash'][$key]);
    return $msg;
}

function sanitize(string $s): string {
    return htmlspecialchars(trim($s), ENT_QUOTES, 'UTF-8');
}
?>

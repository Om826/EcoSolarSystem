<?php
require_once __DIR__ . '/../includes/functions.php';
$customer = currentCustomer();
$cartCount = cartCount();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? sanitize($pageTitle) . ' — eSolar' : 'eSolar — Clean Energy for Every Home' ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= SITE_URL ?>/assets/css/style.css">
</head>
<body>

<header class="site-header">
  <div class="container header-inner">
    <a href="<?= SITE_URL ?>" class="logo">
      <span class="logo-icon">☀</span>
      <span class="logo-text">e<strong>Solar</strong></span>
    </a>
    <nav class="main-nav">
      <a href="<?= SITE_URL ?>">Home</a>
      <a href="<?= SITE_URL ?>/products.php">Products</a>
      <?php if ($customer): ?>
        <a href="<?= SITE_URL ?>/orders.php">My Orders</a>
        <a href="<?= SITE_URL ?>/logout.php" class="nav-logout">Logout</a>
        <span class="nav-user">👤 <?= sanitize(explode(' ', $customer['name'])[0]) ?></span>
      <?php else: ?>
        <a href="<?= SITE_URL ?>/login.php">Login</a>
        <a href="<?= SITE_URL ?>/register.php" class="btn-nav">Register</a>
      <?php endif; ?>
      <a href="<?= SITE_URL ?>/cart.php" class="cart-btn">
        🛒 Cart <?php if ($cartCount > 0): ?><span class="cart-badge"><?= $cartCount ?></span><?php endif; ?>
      </a>
    </nav>
  </div>
</header>

<?php
$successMsg = getFlash('success');
$errorMsg   = getFlash('error');
if ($successMsg): ?>
<div class="flash flash-success"><?= sanitize($successMsg) ?></div>
<?php endif;
if ($errorMsg): ?>
<div class="flash flash-error"><?= sanitize($errorMsg) ?></div>
<?php endif; ?>

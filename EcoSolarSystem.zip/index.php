<?php
require_once 'includes/functions.php';
$pageTitle = 'Clean Energy for Every Home';

$pdo = getDB();

// Featured products (4 random active ones)
$featured = $pdo->query('SELECT p.*, c.name AS cat_name, c.icon AS cat_icon FROM products p JOIN categories c ON p.category_id = c.id WHERE p.is_active = 1 ORDER BY RAND() LIMIT 8')->fetchAll();

// Categories with product count
$categories = $pdo->query('SELECT c.*, COUNT(p.id) AS product_count FROM categories c LEFT JOIN products p ON p.category_id = c.id AND p.is_active = 1 GROUP BY c.id')->fetchAll();

// Handle add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    addToCart((int)$_POST['product_id'], 1);
    flash('success', 'Product added to cart!');
    header('Location: /esolar/');
    exit;
}

// Category icons map
$icons = ['solar-panels'=>'🌞','solar-inverters'=>'⚡','solar-batteries'=>'🔋','solar-water-heaters'=>'🚿'];

include 'includes/header.php';
?>

<!-- Hero -->
<section class="hero">
  <div class="container">
    <div class="hero-content">
      <div class="hero-badge">🌱 India's Trusted Solar Store</div>
      <h1>Power Your Home with <span>Clean Solar</span> Energy</h1>
      <p>Shop premium solar panels, inverters, batteries & water heaters from top brands. Free delivery across India. Expert installation support.</p>
      <div class="hero-btns">
        <a href="products.php" class="btn btn-primary">Shop Now →</a>
        <a href="#categories" class="btn btn-secondary">Browse Categories</a>
      </div>
    </div>
  </div>
</section>

<!-- Stats -->
<div class="stats-bar">
  <div class="container stats-inner">
    <div class="stat-item"><strong>1200+</strong><span>Happy Customers</span></div>
    <div class="stat-item"><strong>50+</strong><span>Solar Products</span></div>
    <div class="stat-item"><strong>10 MW+</strong><span>Energy Installed</span></div>
    <div class="stat-item"><strong>5★</strong><span>Customer Rating</span></div>
  </div>
</div>

<!-- Categories -->
<section class="section" id="categories">
  <div class="container">
    <div class="section-header">
      <h2>Browse by Category</h2>
      <p>Everything you need to go solar — under one roof</p>
    </div>
    <div class="cat-grid">
      <?php foreach ($categories as $cat): ?>
      <a href="products.php?cat=<?= $cat['slug'] ?>" class="cat-card">
        <div class="cat-icon"><?= $icons[$cat['slug']] ?? '☀️' ?></div>
        <h3><?= sanitize($cat['name']) ?></h3>
        <p><?= $cat['product_count'] ?> products available</p>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Featured Products -->
<section class="section section-alt">
  <div class="container">
    <div class="section-header">
      <h2>Featured Products</h2>
      <p>Top-rated solar products, curated for Indian homes and businesses</p>
    </div>
    <div class="products-grid">
      <?php foreach ($featured as $p): ?>
      <div class="product-card">
        <div class="product-img">
          <span class="product-badge"><?= sanitize($p['cat_name']) ?></span>
          <?= $icons[$p['cat_icon'] ?? ''] ?? $p['cat_icon'] ?>
        </div>
        <div class="product-body">
          <div class="product-brand"><?= sanitize($p['brand'] ?? '') ?></div>
          <div class="product-name"><?= sanitize($p['name']) ?></div>
          <div class="product-desc"><?= sanitize(substr($p['description'], 0, 90)) ?>…</div>
          <div class="product-specs">
            <?php if ($p['wattage']): ?><span class="spec-tag">⚡ <?= sanitize($p['wattage']) ?></span><?php endif; ?>
            <?php if ($p['warranty']): ?><span class="spec-tag">🛡 <?= sanitize($p['warranty']) ?></span><?php endif; ?>
          </div>
          <div class="product-footer">
            <div>
              <div class="product-price"><?= formatPrice($p['price']) ?></div>
              <div class="stock-info"><?= $p['stock'] > 0 ? '✅ In Stock ('.$p['stock'].')' : '❌ Out of Stock' ?></div>
            </div>
          </div>
          <div class="product-actions">
            <a href="product.php?id=<?= $p['id'] ?>" class="btn btn-outline btn-sm" style="flex:1">View</a>
            <?php if ($p['stock'] > 0): ?>
            <form method="POST" style="flex:1">
              <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
              <button type="submit" name="add_to_cart" class="btn btn-primary btn-sm btn-full">Add to Cart</button>
            </form>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="text-center mt-3">
      <a href="products.php" class="btn btn-dark">View All Products →</a>
    </div>
  </div>
</section>

<!-- Why eSolar -->
<section class="section section-dark">
  <div class="container">
    <div class="section-header">
      <h2>Why Choose eSolar?</h2>
      <p>India's most trusted online solar marketplace</p>
    </div>
    <div class="cat-grid" style="--card-bg:#1E293B">
      <div class="cat-card" style="background:#1E293B;border-color:#334155;color:white">
        <div class="cat-icon">🏭</div>
        <h3 style="color:white">Top Brands</h3>
        <p>Luminous, Adani, Havells, V-Guard and more — only genuine products.</p>
      </div>
      <div class="cat-card" style="background:#1E293B;border-color:#334155;color:white">
        <div class="cat-icon">🚚</div>
        <h3 style="color:white">Free Delivery</h3>
        <p>Free shipping across India on orders above ₹10,000.</p>
      </div>
      <div class="cat-card" style="background:#1E293B;border-color:#334155;color:white">
        <div class="cat-icon">🔧</div>
        <h3 style="color:white">Expert Support</h3>
        <p>Our solar engineers are available 6 days a week for installation guidance.</p>
      </div>
      <div class="cat-card" style="background:#1E293B;border-color:#334155;color:white">
        <div class="cat-icon">🛡</div>
        <h3 style="color:white">Warranty Backed</h3>
        <p>All products carry manufacturer warranty with easy claim support.</p>
      </div>
    </div>
  </div>
</section>

<?php include 'includes/footer.php'; ?>

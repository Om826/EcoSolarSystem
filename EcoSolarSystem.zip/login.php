<?php
require_once 'includes/functions.php';
if (isLoggedIn()) { header('Location: ' . SITE_URL); exit; }
$pageTitle = 'Login';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if (!$email || !$pass) {
        $error = 'Please enter your email and password.';
    } else {
        $pdo  = getDB();
        $stmt = $pdo->prepare('SELECT * FROM customers WHERE email = ?');
        $stmt->execute([$email]);
        $customer = $stmt->fetch();

        if ($customer && password_verify($pass, $customer['password_hash'])) {
            $_SESSION['customer_id'] = $customer['id'];
            flash('success', 'Welcome back, ' . $customer['name'] . '!');
            $redirect = $_GET['redirect'] ?? SITE_URL;
            header('Location: ' . $redirect);
            exit;
        } else {
            $error = 'Invalid email or password. Please try again.';
        }
    }
}
include 'includes/header.php';
?>

<div class="form-page">
  <div class="form-card">
    <div style="text-align:center;margin-bottom:1.5rem">
      <span style="font-size:2.5rem">☀</span>
    </div>
    <h2 class="form-title">Welcome Back!</h2>
    <p class="form-subtitle">Login to your eSolar account</p>

    <?php if ($error): ?>
      <div class="flash flash-error" style="margin-bottom:1rem;border-radius:8px"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label>Email Address</label>
        <input type="email" name="email" value="<?= sanitize($_POST['email'] ?? '') ?>" placeholder="you@example.com" required autofocus>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Your password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-full" style="margin-top:.5rem">Login →</button>
    </form>
    <div class="form-footer" style="margin-top:1rem">
      New to eSolar? <a href="register.php">Create an account</a>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>

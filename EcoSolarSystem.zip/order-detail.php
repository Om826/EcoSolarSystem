<?php
require_once 'includes/functions.php';
requireLogin();
$pdo = getDB();
$oid = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT o.*, py.transaction_id, py.card_last4, py.card_type, py.paid_at FROM orders o LEFT JOIN payments py ON py.order_id = o.id WHERE o.id = ? AND o.customer_id = ?');
$stmt->execute([$oid, $_SESSION['customer_id']]);
$order = $stmt->fetch();
if (!$order) { header('Location: ' . SITE_URL . '/orders.php'); exit; }

$pageTitle = 'Order #' . $order['order_number'];

$items = $pdo->prepare('SELECT oi.*, p.name, p.brand FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id = ?');
$items->execute([$oid]);
$items = $items->fetchAll();

include 'includes/header.php';
?>

<div class="page-header">
  <div class="container">
    <div class="breadcrumb"><a href="<?= SITE_URL ?>">Home</a> › <a href="orders.php">My Orders</a> › <?= sanitize($order['order_number']) ?></div>
    <h1>Order <?= sanitize($order['order_number']) ?></h1>
    <p>Placed on <?= date('d M Y, H:i', strtotime($order['created_at'])) ?></p>
  </div>
</div>

<div class="container" style="padding-bottom:3rem;display:grid;grid-template-columns:1fr 320px;gap:2rem;align-items:start">
  <div>
    <!-- Items -->
    <div class="card mb-3">
      <h3 style="margin-bottom:1rem">Order Items</h3>
      <div class="table-wrap" style="box-shadow:none">
        <table>
          <thead><tr><th>Product</th><th>Brand</th><th>Qty</th><th>Unit Price</th><th>Subtotal</th></tr></thead>
          <tbody>
            <?php foreach ($items as $it): ?>
            <tr>
              <td><?= sanitize($it['name']) ?></td>
              <td><?= sanitize($it['brand'] ?? '—') ?></td>
              <td><?= $it['quantity'] ?></td>
              <td><?= formatPrice($it['unit_price']) ?></td>
              <td><strong><?= formatPrice($it['subtotal']) ?></strong></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Payment Info -->
    <div class="card">
      <h3 style="margin-bottom:1rem">Payment Details</h3>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem">
        <div><div class="text-muted" style="font-size:.82rem">Transaction ID</div><strong><?= sanitize($order['transaction_id'] ?? 'N/A') ?></strong></div>
        <div><div class="text-muted" style="font-size:.82rem">Payment Method</div><strong><?= ucfirst(sanitize($order['payment_method'])) ?></strong></div>
        <?php if ($order['card_last4']): ?>
        <div><div class="text-muted" style="font-size:.82rem">Card</div><strong><?= sanitize($order['card_type']) ?> ending in <?= $order['card_last4'] ?></strong></div>
        <?php endif; ?>
        <div><div class="text-muted" style="font-size:.82rem">Payment Status</div><span class="status-badge pay-<?= $order['payment_status'] ?>"><?= ucfirst($order['payment_status']) ?></span></div>
        <?php if ($order['paid_at']): ?>
        <div><div class="text-muted" style="font-size:.82rem">Paid At</div><strong><?= date('d M Y H:i', strtotime($order['paid_at'])) ?></strong></div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Right Panel -->
  <div>
    <div class="order-summary mb-3">
      <h3>Order Summary</h3>
      <div class="summary-row"><span>Subtotal</span><span><?= formatPrice($order['total_amount'] / 1.18) ?></span></div>
      <div class="summary-row"><span>GST (18%)</span><span><?= formatPrice($order['total_amount'] - $order['total_amount'] / 1.18) ?></span></div>
      <div class="summary-row total"><span>Total Paid</span><span><?= formatPrice($order['total_amount']) ?></span></div>
    </div>

    <div class="card mb-3">
      <h4 style="margin-bottom:.75rem">Order Status</h4>
      <span class="status-badge status-<?= $order['status'] ?>" style="font-size:.9rem"><?= ucfirst($order['status']) ?></span>
    </div>

    <div class="card">
      <h4 style="margin-bottom:.75rem">Shipping Address</h4>
      <p style="font-size:.88rem;white-space:pre-wrap;color:var(--gray-700)"><?= sanitize($order['shipping_address']) ?></p>
    </div>

    <?php if ($order['notes']): ?>
    <div class="card mt-2">
      <h4 style="margin-bottom:.5rem">Your Notes</h4>
      <p style="font-size:.88rem;color:var(--gray-700)"><?= sanitize($order['notes']) ?></p>
    </div>
    <?php endif; ?>

    <div style="margin-top:1rem">
      <a href="orders.php" class="btn btn-outline btn-full">← Back to Orders</a>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>

<?php
require_once 'includes/functions.php';
requireLogin();
$pageTitle = 'My Orders';
$pdo      = getDB();
$cid      = $_SESSION['customer_id'];

$orders = $pdo->prepare('SELECT o.*, COUNT(oi.id) AS item_count FROM orders o LEFT JOIN order_items oi ON oi.order_id = o.id WHERE o.customer_id = ? GROUP BY o.id ORDER BY o.created_at DESC');
$orders->execute([$cid]);
$orders = $orders->fetchAll();

include 'includes/header.php';
?>

<div class="page-header">
  <div class="container">
    <div class="breadcrumb"><a href="<?= SITE_URL ?>">Home</a> › My Orders</div>
    <h1>My Orders</h1>
    <p>Track all your eSolar purchases</p>
  </div>
</div>

<div class="container" style="padding-bottom:3rem">
  <?php if (empty($orders)): ?>
  <div class="empty-state">
    <div class="empty-icon">📦</div>
    <h3>No orders yet</h3>
    <p>When you place an order, it will show up here.</p>
    <a href="products.php" class="btn btn-primary mt-2">Start Shopping</a>
  </div>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Order #</th>
          <th>Date</th>
          <th>Items</th>
          <th>Total</th>
          <th>Payment</th>
          <th>Status</th>
          <th>Details</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($orders as $o): ?>
        <tr>
          <td><strong style="color:var(--solar-orange)"><?= sanitize($o['order_number']) ?></strong></td>
          <td><?= date('d M Y, H:i', strtotime($o['created_at'])) ?></td>
          <td><?= $o['item_count'] ?> item<?= $o['item_count'] != 1 ? 's' : '' ?></td>
          <td><strong><?= formatPrice($o['total_amount']) ?></strong></td>
          <td><span class="status-badge pay-<?= $o['payment_status'] ?>"><?= ucfirst($o['payment_status']) ?></span></td>
          <td><span class="status-badge status-<?= $o['status'] ?>"><?= ucfirst($o['status']) ?></span></td>
          <td><a href="order-detail.php?id=<?= $o['id'] ?>" class="btn btn-outline btn-sm">View</a></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>

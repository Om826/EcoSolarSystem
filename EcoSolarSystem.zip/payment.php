<?php
require_once 'includes/functions.php';
requireLogin();
$pageTitle = 'Payment';

$cart = getCart();
if (empty($cart) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . SITE_URL . '/cart.php');
    exit;
}

// Retrieve checkout data from POST
$shipName    = trim($_POST['ship_name'] ?? '');
$shipPhone   = trim($_POST['ship_phone'] ?? '');
$shipAddress = trim($_POST['ship_address'] ?? '');
$shipCity    = trim($_POST['ship_city'] ?? '');
$shipState   = trim($_POST['ship_state'] ?? '');
$shipPincode = trim($_POST['ship_pincode'] ?? '');
$notes       = trim($_POST['notes'] ?? '');
$grandTotal  = (float)($_POST['grand_total'] ?? 0);

// If payment form was submitted (step 2)
$paymentDone = false;
$orderId     = null;
$orderNumber = null;

if (isset($_POST['pay_now'])) {
    $cardHolder = trim($_POST['card_holder'] ?? '');
    $cardNumber = preg_replace('/\D/', '', $_POST['card_number'] ?? '');
    $expiry     = trim($_POST['expiry'] ?? '');
    $cvv        = trim($_POST['cvv'] ?? '');
    $payMethod  = trim($_POST['pay_method'] ?? 'card');

    $errors = [];
    if ($payMethod === 'card') {
        if (strlen($cardNumber) < 13) $errors[] = 'Enter a valid card number.';
        if (!$cardHolder)             $errors[] = 'Enter card holder name.';
        if (!$expiry)                 $errors[] = 'Enter expiry date.';
        if (strlen($cvv) < 3)        $errors[] = 'Enter valid CVV.';
    }

    if (empty($errors)) {
        $pdo = getDB();
        try {
            $pdo->beginTransaction();

            // Create order
            $shippingFull = "$shipName, $shipPhone\n$shipAddress\n$shipCity, $shipState - $shipPincode";
            $orderNum     = generateOrderNumber();
            $stmt = $pdo->prepare('INSERT INTO orders (customer_id,order_number,total_amount,shipping_address,status,payment_status,payment_method,notes) VALUES (?,?,?,?,?,?,?,?)');
            $stmt->execute([
                $_SESSION['customer_id'],
                $orderNum,
                $grandTotal,
                $shippingFull,
                'confirmed',
                'paid',
                $payMethod,
                $notes
            ]);
            $orderId = $pdo->lastInsertId();

            // Insert order items & reduce stock
            foreach ($cart as $pid => $item) {
                $ins = $pdo->prepare('INSERT INTO order_items (order_id,product_id,quantity,unit_price,subtotal) VALUES (?,?,?,?,?)');
                $subtotal = $item['price'] * $item['qty'];
                $ins->execute([$orderId, $pid, $item['qty'], $item['price'], $subtotal]);
                // Reduce stock
                $pdo->prepare('UPDATE products SET stock = stock - ? WHERE id = ?')->execute([$item['qty'], $pid]);
            }

            // Dummy payment record
            $txnId = 'TXN' . strtoupper(bin2hex(random_bytes(6)));
            $last4 = $payMethod === 'card' ? substr($cardNumber, -4) : null;
            $cardType = '';
            if ($cardNumber) {
                $first = substr($cardNumber, 0, 1);
                $cardType = $first === '4' ? 'Visa' : ($first === '5' ? 'Mastercard' : 'Card');
            }
            $pay = $pdo->prepare('INSERT INTO payments (order_id,card_holder_name,card_last4,card_type,amount,transaction_id,status) VALUES (?,?,?,?,?,?,?)');
            $pay->execute([$orderId, $cardHolder ?: null, $last4, $cardType ?: $payMethod, $grandTotal, $txnId, 'success']);

            $pdo->commit();
            clearCart();
            $orderNumber = $orderNum;
            $paymentDone = true;
        } catch (Exception $e) {
            $pdo->rollBack();
            $errors[] = 'Order could not be placed. Please try again.';
        }
    }
}

include 'includes/header.php';
?>

<div class="page-header">
  <div class="container">
    <div class="breadcrumb"><a href="<?= SITE_URL ?>">Home</a> › <a href="cart.php">Cart</a> › <a href="checkout.php">Checkout</a> › Payment</div>
    <h1>💳 Secure Payment</h1>
  </div>
</div>

<div class="container" style="padding-bottom:3rem">
<?php if ($paymentDone): ?>
  <!-- SUCCESS -->
  <div style="max-width:560px;margin:2rem auto;text-align:center">
    <div class="card">
      <div style="font-size:4rem;margin-bottom:1rem">🎉</div>
      <h2 style="color:var(--success);margin-bottom:.5rem">Payment Successful!</h2>
      <p style="color:var(--gray-500);margin-bottom:1.5rem">Thank you for your order. Your eSolar products are confirmed!</p>
      <div style="background:var(--gray-100);border-radius:10px;padding:1.25rem;margin-bottom:1.5rem">
        <div style="font-size:.85rem;color:var(--gray-500)">Order Number</div>
        <div style="font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;color:var(--solar-orange)"><?= sanitize($orderNumber) ?></div>
        <div style="font-size:.85rem;color:var(--gray-500);margin-top:.5rem">Amount Paid</div>
        <div style="font-family:'Syne',sans-serif;font-size:1.2rem;font-weight:700"><?= formatPrice($grandTotal) ?></div>
      </div>
      <p style="font-size:.9rem;color:var(--gray-500);margin-bottom:1.5rem">We will notify you when your order is shipped. Expected delivery: 5–7 business days.</p>
      <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap">
        <a href="orders.php" class="btn btn-primary">Track My Order</a>
        <a href="products.php" class="btn btn-outline">Continue Shopping</a>
      </div>
    </div>
  </div>

<?php elseif (!$paymentDone): ?>
  <?php if (!empty($errors)): ?>
    <div class="flash flash-error" style="margin-bottom:1rem;border-radius:8px"><?= implode('<br>', array_map('sanitize', $errors)) ?></div>
  <?php endif; ?>

  <div class="cart-layout">
    <!-- Payment Form -->
    <div>
      <div class="card">
        <h3 style="margin-bottom:1.25rem">Choose Payment Method</h3>

        <!-- Method Tabs -->
        <div style="display:flex;gap:.75rem;margin-bottom:1.5rem;flex-wrap:wrap" id="methodTabs">
          <button type="button" class="btn btn-primary btn-sm" onclick="selectMethod('card',this)" id="tab-card">💳 Card</button>
          <button type="button" class="btn btn-outline btn-sm" onclick="selectMethod('upi',this)" id="tab-upi">📱 UPI</button>
          <button type="button" class="btn btn-outline btn-sm" onclick="selectMethod('netbanking',this)" id="tab-net">🏦 Net Banking</button>
          <button type="button" class="btn btn-outline btn-sm" onclick="selectMethod('cod',this)" id="tab-cod">💵 Cash on Delivery</button>
        </div>

        <form method="POST" id="payForm">
          <!-- Hidden checkout data passed through -->
          <input type="hidden" name="ship_name"    value="<?= sanitize($shipName) ?>">
          <input type="hidden" name="ship_phone"   value="<?= sanitize($shipPhone) ?>">
          <input type="hidden" name="ship_address" value="<?= sanitize($shipAddress) ?>">
          <input type="hidden" name="ship_city"    value="<?= sanitize($shipCity) ?>">
          <input type="hidden" name="ship_state"   value="<?= sanitize($shipState) ?>">
          <input type="hidden" name="ship_pincode" value="<?= sanitize($shipPincode) ?>">
          <input type="hidden" name="notes"        value="<?= sanitize($notes) ?>">
          <input type="hidden" name="grand_total"  value="<?= $grandTotal ?>">
          <input type="hidden" name="pay_method"   id="payMethod" value="card">
          <input type="hidden" name="pay_now" value="1">

          <!-- Card Section -->
          <div id="section-card">
            <div class="card-preview">
              <div class="card-chip"></div>
              <div class="card-num" id="prev-num">**** **** **** ****</div>
              <div class="card-meta">
                <div>
                  <div style="font-size:.7rem;opacity:.7;margin-bottom:.2rem">CARD HOLDER</div>
                  <div id="prev-name">YOUR NAME</div>
                </div>
                <div>
                  <div style="font-size:.7rem;opacity:.7;margin-bottom:.2rem">EXPIRES</div>
                  <div id="prev-exp">MM/YY</div>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label>Card Number</label>
              <input type="text" id="card_number" name="card_number" placeholder="1234 5678 9012 3456" maxlength="19">
            </div>
            <div class="form-group">
              <label>Card Holder Name</label>
              <input type="text" id="card_holder" name="card_holder" placeholder="Name as on card">
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Expiry (MM/YY)</label>
                <input type="text" id="expiry" name="expiry" placeholder="08/27" maxlength="5">
              </div>
              <div class="form-group">
                <label>CVV</label>
                <input type="password" name="cvv" id="cvv" placeholder="•••" maxlength="4">
              </div>
            </div>
            <div class="form-hint" style="margin-bottom:1rem">🔒 This is a demo payment — no real charges will be made.</div>
          </div>

          <!-- UPI Section -->
          <div id="section-upi" style="display:none">
            <div class="form-group">
              <label>UPI ID</label>
              <input type="text" name="upi_id" placeholder="yourname@upi">
              <div class="form-hint">e.g., 9876543210@paytm or name@okaxis</div>
            </div>
            <div class="form-hint" style="margin-bottom:1rem">🔒 Demo UPI — no actual transaction will occur.</div>
          </div>

          <!-- Net Banking Section -->
          <div id="section-net" style="display:none">
            <div class="form-group">
              <label>Select Bank</label>
              <select name="bank">
                <option>State Bank of India</option>
                <option>HDFC Bank</option>
                <option>ICICI Bank</option>
                <option>Axis Bank</option>
                <option>Kotak Mahindra Bank</option>
                <option>Bank of Baroda</option>
                <option>Punjab National Bank</option>
              </select>
            </div>
            <div class="form-hint" style="margin-bottom:1rem">🔒 Demo net banking — you will not be redirected to any bank.</div>
          </div>

          <!-- COD Section -->
          <div id="section-cod" style="display:none">
            <div style="background:#fef3c7;border-radius:10px;padding:1.25rem;margin-bottom:1rem">
              <h4 style="margin-bottom:.5rem">Cash on Delivery</h4>
              <p style="font-size:.9rem;color:#78350f">Pay <?= formatPrice($grandTotal) ?> in cash when your order is delivered. COD charges of ₹50 may apply.</p>
            </div>
          </div>

          <button type="submit" class="btn btn-primary btn-full" style="font-size:1rem">
            🔒 Pay <?= formatPrice($grandTotal) ?> Now
          </button>
        </form>
      </div>
    </div>

    <!-- Order Summary -->
    <div class="order-summary">
      <h3>Order Summary</h3>
      <?php foreach ($cart as $item): ?>
      <div class="summary-row">
        <span><?= sanitize(substr($item['name'],0,26)) ?>… × <?= $item['qty'] ?></span>
        <span><?= formatPrice($item['price'] * $item['qty']) ?></span>
      </div>
      <?php endforeach; ?>
      <div class="summary-row"><span>Subtotal</span><span><?= formatPrice(cartTotal()) ?></span></div>
      <div class="summary-row"><span>Shipping</span><span><?= $grandTotal - cartTotal() - round(cartTotal()*0.18,2) === 0.0 ? '<span style="color:var(--success)">FREE</span>' : formatPrice(500) ?></span></div>
      <div class="summary-row"><span>GST 18%</span><span><?= formatPrice(round(cartTotal()*0.18,2)) ?></span></div>
      <div class="summary-row total"><span>Total</span><span><?= formatPrice($grandTotal) ?></span></div>
      <div style="margin-top:1rem;font-size:.8rem">
        <div style="color:var(--gray-500);margin-bottom:.5rem">📦 Shipping to:</div>
        <div style="font-size:.85rem"><?= sanitize("$shipName, $shipCity, $shipState") ?></div>
      </div>
    </div>
  </div>
<?php endif; ?>
</div>

<script>
function selectMethod(method, btn) {
  document.getElementById('payMethod').value = method;
  ['card','upi','net','cod'].forEach(m => {
    const sec = document.getElementById('section-' + (m==='net'?'net':m));
    const tab = document.getElementById('tab-' + m);
    if (sec) sec.style.display = 'none';
    if (tab) { tab.classList.remove('btn-primary'); tab.classList.add('btn-outline'); }
  });
  const secMap = {card:'card',upi:'upi',netbanking:'net',cod:'cod'};
  const sectionId = 'section-' + secMap[method];
  const s = document.getElementById(sectionId);
  if (s) s.style.display = 'block';
  if (btn) { btn.classList.add('btn-primary'); btn.classList.remove('btn-outline'); }
}
</script>
<?php include 'includes/footer.php'; ?>

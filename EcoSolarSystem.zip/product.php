<?php
require_once 'includes/functions.php';
$pdo = getDB();
$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare('SELECT p.*, c.name AS cat_name, c.slug AS cat_slug, c.icon AS cat_icon FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ? AND p.is_active = 1');
$stmt->execute([$id]);
$p = $stmt->fetch();
if (!$p) { header('Location: ' . SITE_URL . '/products.php'); exit; }

$pageTitle = $p['name'];
$icons = ['solar-panels'=>'🌞','solar-inverters'=>'⚡','solar-batteries'=>'🔋','solar-water-heaters'=>'🚿'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $qty = max(1, (int)($_POST['qty'] ?? 1));
    addToCart($p['id'], $qty);
    flash('success', 'Product added to cart!');
    header('Location: product.php?id=' . $p['id']);
    exit;
}

// Related products
$rel = $pdo->prepare('SELECT * FROM products WHERE category_id = ? AND id != ? AND is_active = 1 LIMIT 4');
$rel->execute([$p['category_id'], $p['id']]);
$related = $rel->fetchAll();

include 'includes/header.php';
?>

<div class="page-header">
  <div class="container">
    <div class="breadcrumb">
      <a href="<?= SITE_URL ?>">Home</a> ›
      <a href="products.php?cat=<?= $p['cat_slug'] ?>"><?= sanitize($p['cat_name']) ?></a> ›
      <?= sanitize($p['name']) ?>
    </div>
  </div>
</div>

<div class="container section">
  <div class="product-detail-layout">
    <div>
      <div class="product-detail-img"><?= $icons[$p['cat_slug']] ?? '☀️' ?></div>
    </div>
    <div>
      <div style="font-size:.8rem;color:var(--solar-orange);font-weight:700;text-transform:uppercase;letter-spacing:.08em;margin-bottom:.5rem"><?= sanitize($p['cat_name']) ?></div>
      <h1 style="font-size:1.6rem;margin-bottom:.5rem"><?= sanitize($p['name']) ?></h1>
      <?php if ($p['brand']): ?>
        <div style="color:var(--gray-500);margin-bottom:.5rem">Brand: <strong><?= sanitize($p['brand']) ?></strong></div>
      <?php endif; ?>
      <div class="product-detail-price"><?= formatPrice($p['price']) ?></div>

      <p style="color:var(--gray-700);line-height:1.7;margin-bottom:1.5rem"><?= sanitize($p['description']) ?></p>

      <div class="product-meta-grid">
        <?php if ($p['wattage']): ?>
        <div class="meta-item"><span>Capacity / Wattage</span><strong>⚡ <?= sanitize($p['wattage']) ?></strong></div>
        <?php endif; ?>
        <?php if ($p['warranty']): ?>
        <div class="meta-item"><span>Warranty</span><strong>🛡 <?= sanitize($p['warranty']) ?></strong></div>
        <?php endif; ?>
        <?php if ($p['brand']): ?>
        <div class="meta-item"><span>Brand</span><strong><?= sanitize($p['brand']) ?></strong></div>
        <?php endif; ?>
        <div class="meta-item">
          <span>Availability</span>
          <strong><?= $p['stock'] > 0 ? '✅ In Stock ('.$p['stock'].' units)' : '❌ Out of Stock' ?></strong>
        </div>
      </div>

      <?php if ($p['stock'] > 0): ?>
      <form method="POST" style="display:flex;gap:1rem;align-items:center;flex-wrap:wrap">
        <div>
          <label style="font-size:.85rem;font-weight:500;display:block;margin-bottom:.3rem">Quantity</label>
          <input type="number" name="qty" value="1" min="1" max="<?= $p['stock'] ?>" style="width:80px;padding:.6rem;border:1.5px solid #e2e8f0;border-radius:8px;font-size:1rem;text-align:center">
        </div>
        <button type="submit" name="add_to_cart" class="btn btn-primary" style="flex:1;margin-top:1.4rem">🛒 Add to Cart</button>
        <a href="cart.php" class="btn btn-outline" style="flex:1;margin-top:1.4rem">View Cart</a>
      </form>
      <?php else: ?>
        <div class="btn btn-danger" style="opacity:.6;cursor:not-allowed">Out of Stock</div>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($related): ?>
  <div style="margin-top:3rem">
    <h2 style="margin-bottom:1.5rem">Related Products</h2>
    <div class="products-grid">
      <?php foreach ($related as $r): ?>
      <div class="product-card">
        <div class="product-img"><?= $icons[$p['cat_slug']] ?? '☀️' ?></div>
        <div class="product-body">
          <div class="product-brand"><?= sanitize($r['brand'] ?? '') ?></div>
          <div class="product-name"><?= sanitize($r['name']) ?></div>
          <div class="product-footer">
            <div class="product-price"><?= formatPrice($r['price']) ?></div>
          </div>
          <div class="product-actions">
            <a href="product.php?id=<?= $r['id'] ?>" class="btn btn-outline btn-sm btn-full">View Product</a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>

<?php
require_once 'includes/functions.php';
$pageTitle = 'All Products';
$pdo = getDB();

$catSlug = $_GET['cat'] ?? '';
$search  = trim($_GET['q'] ?? '');
$sort    = $_GET['sort'] ?? 'newest';

// Filter by category
$catRow = null;
if ($catSlug) {
    $stmt = $pdo->prepare('SELECT * FROM categories WHERE slug = ?');
    $stmt->execute([$catSlug]);
    $catRow = $stmt->fetch();
}

// Build query
$where  = ['p.is_active = 1'];
$params = [];
if ($catRow) { $where[] = 'p.category_id = ?'; $params[] = $catRow['id']; }
if ($search)  { $where[] = '(p.name LIKE ? OR p.brand LIKE ? OR p.description LIKE ?)'; $params = array_merge($params, ["%$search%","%$search%","%$search%"]); }

$orderBy = match($sort) {
    'price_asc'  => 'p.price ASC',
    'price_desc' => 'p.price DESC',
    'name'       => 'p.name ASC',
    default      => 'p.id DESC'
};

$sql = 'SELECT p.*, c.name AS cat_name, c.slug AS cat_slug, c.icon AS cat_icon FROM products p JOIN categories c ON p.category_id = c.id WHERE ' . implode(' AND ', $where) . " ORDER BY $orderBy";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $pdo->query('SELECT * FROM categories')->fetchAll();
$icons = ['solar-panels'=>'🌞','solar-inverters'=>'⚡','solar-batteries'=>'🔋','solar-water-heaters'=>'🚿'];

// Add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    addToCart((int)$_POST['product_id'], 1);
    flash('success', 'Product added to cart!');
    header('Location: ' . $_SERVER['REQUEST_URI']);
    exit;
}

include 'includes/header.php';
?>

<div class="page-header">
  <div class="container">
    <div class="breadcrumb"><a href="<?= SITE_URL ?>">Home</a> › Products</div>
    <h1><?= $catRow ? sanitize($catRow['name']) : ($search ? 'Search: '.sanitize($search) : 'All Products') ?></h1>
    <p><?= count($products) ?> products found</p>
  </div>
</div>

<div class="container" style="padding-bottom:3rem">
  <!-- Filters -->
  <form method="GET" style="display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:1.5rem;align-items:center">
    <input type="text" name="q" value="<?= sanitize($search) ?>" placeholder="Search products…" style="padding:.6rem 1rem;border:1.5px solid #e2e8f0;border-radius:8px;flex:1;min-width:200px;font-family:inherit">
    <select name="cat" style="padding:.6rem 1rem;border:1.5px solid #e2e8f0;border-radius:8px;font-family:inherit">
      <option value="">All Categories</option>
      <?php foreach ($categories as $c): ?>
        <option value="<?= $c['slug'] ?>" <?= $catSlug === $c['slug'] ? 'selected' : '' ?>><?= sanitize($c['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="sort" style="padding:.6rem 1rem;border:1.5px solid #e2e8f0;border-radius:8px;font-family:inherit">
      <option value="newest" <?= $sort==='newest'?'selected':'' ?>>Newest First</option>
      <option value="price_asc" <?= $sort==='price_asc'?'selected':'' ?>>Price: Low to High</option>
      <option value="price_desc" <?= $sort==='price_desc'?'selected':'' ?>>Price: High to Low</option>
      <option value="name" <?= $sort==='name'?'selected':'' ?>>Name A–Z</option>
    </select>
    <button type="submit" class="btn btn-primary btn-sm">Filter</button>
    <a href="products.php" class="btn btn-outline btn-sm">Reset</a>
  </form>

  <!-- Category chips -->
  <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1.5rem">
    <a href="products.php" class="btn btn-sm <?= !$catSlug?'btn-dark':'btn-outline' ?>">All</a>
    <?php foreach ($categories as $c): ?>
      <a href="products.php?cat=<?= $c['slug'] ?>" class="btn btn-sm <?= $catSlug===$c['slug']?'btn-dark':'btn-outline' ?>">
        <?= $icons[$c['slug']] ?? '' ?> <?= sanitize($c['name']) ?>
      </a>
    <?php endforeach; ?>
  </div>

  <?php if (empty($products)): ?>
  <div class="empty-state">
    <div class="empty-icon">🔍</div>
    <h3>No products found</h3>
    <p>Try a different search term or category.</p>
    <a href="products.php" class="btn btn-primary mt-2">View All Products</a>
  </div>
  <?php else: ?>
  <div class="products-grid">
    <?php foreach ($products as $p): ?>
    <div class="product-card">
      <div class="product-img">
        <span class="product-badge"><?= sanitize($p['cat_name']) ?></span>
        <?= $icons[$p['cat_slug']] ?? '☀️' ?>
      </div>
      <div class="product-body">
        <div class="product-brand"><?= sanitize($p['brand'] ?? '') ?></div>
        <div class="product-name"><?= sanitize($p['name']) ?></div>
        <div class="product-desc"><?= sanitize(substr($p['description'],0,85)) ?>…</div>
        <div class="product-specs">
          <?php if ($p['wattage']): ?><span class="spec-tag">⚡ <?= sanitize($p['wattage']) ?></span><?php endif; ?>
          <?php if ($p['warranty']): ?><span class="spec-tag">🛡 <?= sanitize($p['warranty']) ?></span><?php endif; ?>
        </div>
        <div class="product-footer">
          <div>
            <div class="product-price"><?= formatPrice($p['price']) ?></div>
            <div class="stock-info"><?= $p['stock']>0?'✅ In Stock ('.$p['stock'].')':'❌ Out of Stock' ?></div>
          </div>
        </div>
        <div class="product-actions">
          <a href="product.php?id=<?= $p['id'] ?>" class="btn btn-outline btn-sm" style="flex:1">View</a>
          <?php if ($p['stock']>0): ?>
          <form method="POST" style="flex:1">
            <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
            <button type="submit" name="add_to_cart" class="btn btn-primary btn-sm btn-full">Add to Cart</button>
          </form>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>

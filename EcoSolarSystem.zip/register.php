<?php
require_once 'includes/functions.php';
if (isLoggedIn()) { header('Location: ' . SITE_URL); exit; }
$pageTitle = 'Create Account';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $address  = trim($_POST['address'] ?? '');
    $city     = trim($_POST['city'] ?? '');
    $state    = trim($_POST['state'] ?? '');
    $pincode  = trim($_POST['pincode'] ?? '');
    $pass     = $_POST['password'] ?? '';
    $pass2    = $_POST['password2'] ?? '';

    if (!$name || !$email || !$pass) {
        $error = 'Name, email and password are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($pass) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($pass !== $pass2) {
        $error = 'Passwords do not match.';
    } else {
        $pdo = getDB();
        $check = $pdo->prepare('SELECT id FROM customers WHERE email = ?');
        $check->execute([$email]);
        if ($check->fetch()) {
            $error = 'An account with this email already exists. <a href="login.php">Login instead?</a>';
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $ins  = $pdo->prepare('INSERT INTO customers (name,email,phone,address,city,state,pincode,password_hash) VALUES (?,?,?,?,?,?,?,?)');
            $ins->execute([$name,$email,$phone,$address,$city,$state,$pincode,$hash]);
            $_SESSION['customer_id'] = $pdo->lastInsertId();
            flash('success', 'Welcome to eSolar, ' . $name . '! Your account has been created.');
            $redirect = $_GET['redirect'] ?? SITE_URL;
            header('Location: ' . $redirect);
            exit;
        }
    }
}
include 'includes/header.php';
?>

<div class="form-page">
  <div class="form-card wide">
    <div style="text-align:center;margin-bottom:1.5rem">
      <span style="font-size:2.5rem">☀</span>
    </div>
    <h2 class="form-title">Create Your Account</h2>
    <p class="form-subtitle">Join eSolar and start your clean energy journey</p>

    <?php if ($error): ?>
      <div class="flash flash-error" style="margin-bottom:1rem;border-radius:8px"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-row">
        <div class="form-group">
          <label>Full Name *</label>
          <input type="text" name="name" value="<?= sanitize($_POST['name'] ?? '') ?>" placeholder="Ramesh Kumar" required>
        </div>
        <div class="form-group">
          <label>Mobile Number</label>
          <input type="tel" name="phone" value="<?= sanitize($_POST['phone'] ?? '') ?>" placeholder="98765 43210">
        </div>
      </div>
      <div class="form-group">
        <label>Email Address *</label>
        <input type="email" name="email" value="<?= sanitize($_POST['email'] ?? '') ?>" placeholder="you@example.com" required>
      </div>
      <div class="form-group">
        <label>Address</label>
        <textarea name="address" placeholder="Street address, flat number…"><?= sanitize($_POST['address'] ?? '') ?></textarea>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>City</label>
          <input type="text" name="city" value="<?= sanitize($_POST['city'] ?? '') ?>" placeholder="Pune">
        </div>
        <div class="form-group">
          <label>State</label>
          <input type="text" name="state" value="<?= sanitize($_POST['state'] ?? '') ?>" placeholder="Maharashtra">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>PIN Code</label>
          <input type="text" name="pincode" value="<?= sanitize($_POST['pincode'] ?? '') ?>" placeholder="411001" maxlength="6">
        </div>
        <div class="form-group"><!-- spacer --></div>
      </div>
      <div class="form-divider"><span>Set Password</span></div>
      <div class="form-row">
        <div class="form-group">
          <label>Password *</label>
          <input type="password" name="password" placeholder="Min 6 characters" required>
        </div>
        <div class="form-group">
          <label>Confirm Password *</label>
          <input type="password" name="password2" placeholder="Repeat password" required>
        </div>
      </div>
      <button type="submit" class="btn btn-primary btn-full">Create Account →</button>
    </form>
    <div class="form-footer">
      Already have an account? <a href="login.php">Login here</a>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
